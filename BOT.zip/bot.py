import asyncio
import hashlib
import json
import math
import os
import random
import re
import threading
import urllib.request
from collections import Counter
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

import discord
from discord.ext import commands

try:
    from google import genai
except Exception:
    genai = None

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)

DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
DEX_FILE = os.path.join(DATA_DIR, 'dex_coins.json')

DEX_COINS = {}
_DATA_LOCK = threading.RLock()

MULTIPLIERS = {
    '🍒': 2,
    '🍋': 2,
    '🍊': 3,
    '🍉': 4,
    '🍇': 5,
    '🔔': 7,
    '⭐': 10,
    '💎': 20,
    '7️⃣': 50,
}
SYMBOLS = list(MULTIPLIERS.keys())
SCRATCH_REWARD_TABLE = {
    4: 0.20,
    5: 0.30,
    6: 0.50,
    7: 0.70,
    8: 1.00,
    9: 1.30,
}
SCRATCH_SESSIONS = {}


def _ensure_data_dir():
    if not os.path.isdir(DATA_DIR):
        os.makedirs(DATA_DIR, exist_ok=True)


def _load_balances():
    _ensure_data_dir()
    if not os.path.isfile(DEX_FILE):
        return
    try:
        with open(DEX_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        for k, v in data.items():
            try:
                DEX_COINS[str(k)] = int(v)
            except Exception:
                DEX_COINS[str(k)] = 0
    except Exception:
        return


def _save_balances():
    _ensure_data_dir()
    tmp = DEX_FILE + '.tmp'
    with _DATA_LOCK:
        try:
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(DEX_COINS, f, ensure_ascii=False, indent=2)
            os.replace(tmp, DEX_FILE)
        except Exception:
            if os.path.isfile(tmp):
                try:
                    os.remove(tmp)
                except Exception:
                    pass


_load_balances()

DEX_MANTES_FILE = os.path.join(DATA_DIR, 'dex_mantes.json')
DEPOSITS_FILE = os.path.join(DATA_DIR, 'dex_mantes_deposits.json')
TERMS_FILE = os.path.join(os.path.dirname(__file__), 'Termos.txt')
MERCADOPAGO_API_FILE = os.path.join(os.path.dirname(__file__), 'MercadoPagoAPI.txt')
DEX_MANTES = {}
DEX_MANTES_DEPOSITS = {}
MERCADO_PAGO_WEBHOOK_PORT = int(os.getenv('MERCADO_PAGO_WEBHOOK_PORT', '8000'))
MERCADO_PAGO_WEBHOOK_PATH = os.getenv('MERCADO_PAGO_WEBHOOK_PATH', '/mercadopago/webhook')
MERCADO_PAGO_WEBHOOK_HOST = os.getenv('MERCADO_PAGO_WEBHOOK_HOST', '0.0.0.0')
MERCADO_PAGO_CLIENT_ID = os.getenv('MERCADO_PAGO_CLIENT_ID')
MERCADO_PAGO_CLIENT_SECRET = os.getenv('MERCADO_PAGO_CLIENT_SECRET')
MERCADO_PAGO_WEBHOOK_SERVER = None


def _load_dex_mantes():
    _ensure_data_dir()
    if not os.path.isfile(DEX_MANTES_FILE):
        return
    try:
        with open(DEX_MANTES_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        for k, v in data.items():
            try:
                DEX_MANTES[str(k)] = Decimal(str(v))
            except Exception:
                DEX_MANTES[str(k)] = Decimal('0.00')
    except Exception:
        return


def _save_dex_mantes():
    _ensure_data_dir()
    tmp = DEX_MANTES_FILE + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump({k: str(v) for k, v in DEX_MANTES.items()}, f, ensure_ascii=False, indent=2)
        os.replace(tmp, DEX_MANTES_FILE)
    except Exception:
        if os.path.isfile(tmp):
            try:
                os.remove(tmp)
            except Exception:
                pass


def _load_deposits():
    _ensure_data_dir()
    if not os.path.isfile(DEPOSITS_FILE):
        return
    try:
        with open(DEPOSITS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        for k, v in data.items():
            DEX_MANTES_DEPOSITS[str(k)] = v
    except Exception:
        return


def _save_deposits():
    _ensure_data_dir()
    tmp = DEPOSITS_FILE + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(DEX_MANTES_DEPOSITS, f, ensure_ascii=False, indent=2)
        os.replace(tmp, DEPOSITS_FILE)
    except Exception:
        if os.path.isfile(tmp):
            try:
                os.remove(tmp)
            except Exception:
                pass


def _to_decimal(value):
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return Decimal('0.00')


def format_decimal_br(value, digits=2):
    decimal_value = _to_decimal(value).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    text = format(decimal_value, f'.{digits}f')
    whole, fraction = text.split('.')
    whole_formatted = f'{int(whole):,}'.replace(',', '.')
    return f'{whole_formatted},{fraction}'


def format_integer_br(value):
    number = int(value)
    return f'{number:,}'.replace(',', '.')


def parse_decimal_input(raw_value):
    if raw_value is None:
        return None
    text = str(raw_value).strip().replace('US$', '').replace('R$', '').replace(' ', '')
    if not text:
        return None
    text = text.replace(',', '.')
    if text.count('.') > 1:
        return None
    if not re.fullmatch(r'\d+(?:\.\d+)?', text):
        return None
    try:
        value = Decimal(text)
    except InvalidOperation:
        return None
    return value


def get_dex_mantes_balance(user_id: int) -> Decimal:
    key = str(user_id)
    if key not in DEX_MANTES:
        DEX_MANTES[key] = Decimal('0.00')
        _save_dex_mantes()
    return DEX_MANTES[key]


def set_dex_mantes_balance(user_id: int, value):
    key = str(user_id)
    DEX_MANTES[key] = _to_decimal(value).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    _save_dex_mantes()
    return DEX_MANTES[key]


def get_mercadopago_token():
    for name in ('MERCADO_PAGO_ACCESS_TOKEN', 'MP_ACCESS_TOKEN', 'ACCESS_TOKEN'):
        token = os.getenv(name)
        if token and token.strip():
            return token.strip()
    if os.path.isfile(MERCADOPAGO_API_FILE):
        try:
            with open(MERCADOPAGO_API_FILE, 'r', encoding='utf-8') as f:
                text = f.read()
            match = re.search(r'Access Token:\s*(APP_[A-Za-z0-9-]+|[A-Za-z0-9-]+)', text, re.IGNORECASE)
            if match:
                return match.group(1).strip()
        except Exception:
            pass
    return None


def get_usd_to_brl_rate():
    rate_value = os.getenv('USD_BRL_RATE')
    if rate_value:
        return _to_decimal(rate_value).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    try:
        with urllib.request.urlopen('https://economia.awesomeapi.com.br/json/last/USD-BRL', timeout=15) as response:
            payload = json.loads(response.read().decode('utf-8'))
        if 'USDBRL' in payload and isinstance(payload['USDBRL'], dict):
            value = payload['USDBRL'].get('bid') or payload['USDBRL'].get('ask')
            if value:
                return _to_decimal(value).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    except Exception:
        pass
    raise ValueError('Não foi possível obter a cotação do dólar no momento.')


def get_deposit_by_id(deposit_id: str):
    return DEX_MANTES_DEPOSITS.get(str(deposit_id))


def create_pending_deposit(user_id: int, amount_usd: Decimal, amount_brl: Decimal, rate: Decimal):
    clean_amount_usd = _to_decimal(amount_usd).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    clean_amount_brl = _to_decimal(amount_brl).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    dex_amount = clean_amount_usd.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    now = datetime.now(timezone.utc)
    deposit_id = f'dep_{user_id}_{int(now.timestamp() * 1000)}_{random.randint(1000, 9999)}'
    record = {
        'deposit_id': deposit_id,
        'user_id': str(user_id),
        'payment_id': None,
        'amount_usd': str(clean_amount_usd),
        'usd_brl_rate': str(rate.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)),
        'amount_brl': str(clean_amount_brl),
        'dex_mantes_amount': str(dex_amount),
        'status': 'PENDING',
        'mercadopago_payment_id': None,
        'mercadopago_preference_id': None,
        'payment_link': None,
        'created_at': now.isoformat(),
        'paid_at': None,
        'refunded_at': None,
        'refund_reason': None,
        'status_history': [{'status': 'PENDING', 'at': now.isoformat()}],
    }
    DEX_MANTES_DEPOSITS[deposit_id] = record
    _save_deposits()
    return record


def update_deposit_status(deposit_id: str, status: str, payment_id=None, payment_link=None, preference_id=None):
    record = DEX_MANTES_DEPOSITS.get(str(deposit_id))
    if record is None:
        return None
    previous_status = record.get('status')
    now = datetime.now(timezone.utc)
    if status:
        record['status'] = status
        if previous_status != status:
            history = record.setdefault('status_history', [])
            duplicate = False
            for item in history:
                raw_at = item.get('at')
                if item.get('status') != status or not raw_at:
                    continue
                try:
                    item_at = datetime.fromisoformat(raw_at)
                except Exception:
                    continue
                if item_at.tzinfo is None:
                    item_at = item_at.replace(tzinfo=timezone.utc)
                if abs((now - item_at).total_seconds()) < 1:
                    duplicate = True
                    break
            if not duplicate:
                history.append({'status': status, 'at': now.isoformat()})
    if payment_id is not None:
        record['mercadopago_payment_id'] = str(payment_id)
        record['payment_id'] = str(payment_id)
    if payment_link is not None:
        record['payment_link'] = payment_link
    if preference_id is not None:
        record['mercadopago_preference_id'] = preference_id
    if status == 'PAID' and not record.get('paid_at'):
        record['paid_at'] = now.isoformat()
    if status in {'REFUNDED', 'CHARGED_BACK', 'CANCELLED'} and not record.get('refunded_at'):
        record['refunded_at'] = now.isoformat()
    _save_deposits()
    return record


def apply_deposit_refund(deposit_id: str, payment_id=None, reason='refund'):
    record = DEX_MANTES_DEPOSITS.get(str(deposit_id))
    if record is None:
        return False
    if record.get('status') in {'REFUNDED', 'CHARGED_BACK'} or record.get('refunded_at'):
        return False
    if payment_id is not None:
        record['mercadopago_payment_id'] = str(payment_id)
    user_id = int(record.get('user_id'))
    refund_amount = _to_decimal(record.get('dex_mantes_amount', '0'))
    current_balance = get_dex_mantes_balance(user_id)
    set_dex_mantes_balance(user_id, current_balance - refund_amount)
    record['status'] = 'REFUNDED'
    record['refunded_at'] = datetime.now(timezone.utc).isoformat()
    record['refund_reason'] = reason
    record['status_history'] = record.get('status_history', [])
    record['status_history'].append({'status': 'REFUNDED', 'at': record['refunded_at'], 'reason': reason})
    _save_deposits()
    return True


def create_mercadopago_preference(deposit_record):
    token = get_mercadopago_token()
    if not token:
        raise ValueError('Token do Mercado Pago não configurado.')
    amount_brl = _to_decimal(deposit_record['amount_brl'])
    url = 'https://api.mercadopago.com/checkout/preferences'
    payload = {
        'items': [{
            'id': deposit_record['deposit_id'],
            'title': '🔷 Dex Mantes',
            'description': f'Depósito de {deposit_record["amount_usd"]} USD em Dex Mantes',
            'quantity': 1,
            'currency_id': 'BRL',
            'unit_price': float(amount_brl),
        }],
        'external_reference': deposit_record['deposit_id'],
        'payer': {'email': 'noreply@dextroier.com'},
        'back_urls': {
            'success': 'https://dextroier.local/success',
            'failure': 'https://dextroier.local/failure',
            'pending': 'https://dextroier.local/pending',
        },
        'auto_return': 'approved',
    }
    if os.getenv('MERCADO_PAGO_WEBHOOK_URL'):
        payload['notification_url'] = os.getenv('MERCADO_PAGO_WEBHOOK_URL') + MERCADO_PAGO_WEBHOOK_PATH
    req = urllib.request.Request(
        url,
        data=json.dumps(payload, separators=(',', ':')).encode('utf-8'),
        headers={
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        },
        method='POST',
    )
    with urllib.request.urlopen(req, timeout=20) as response:
        data = json.loads(response.read().decode('utf-8'))
    if not data.get('init_point'):
        raise ValueError('Resposta inválida da API do Mercado Pago.')
    update_deposit_status(
        deposit_record['deposit_id'],
        deposit_record['status'],
        payment_id=None,
        payment_link=data.get('init_point'),
        preference_id=data.get('id'),
    )
    return data


def get_mercadopago_payment(payment_id: str):
    token = get_mercadopago_token()
    if not token or not payment_id:
        return None
    url = f'https://api.mercadopago.com/v1/payments/{payment_id}'
    req = urllib.request.Request(url, headers={'Authorization': f'Bearer {token}', 'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            return json.loads(response.read().decode('utf-8'))
    except Exception:
        return None


class MercadoPagoWebhookHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        path = urlparse(self.path).path
        if path != MERCADO_PAGO_WEBHOOK_PATH:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b'not-found')
            return
        length = int(self.headers.get('Content-Length', '0'))
        raw_body = self.rfile.read(length) if length > 0 else b''
        payload = {}
        try:
            if raw_body:
                payload = json.loads(raw_body.decode('utf-8'))
        except Exception:
            payload = {}
        process_mercadopago_webhook(payload)
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'ok')

    def log_message(self, format, *args):
        return


def process_mercadopago_webhook(payload):
    if not isinstance(payload, dict):
        return
    payment_id = None
    data_block = payload.get('data') if isinstance(payload.get('data'), dict) else None
    if data_block and isinstance(data_block.get('id'), (str, int)):
        payment_id = str(data_block['id'])
    elif payload.get('resource'):
        resource = str(payload.get('resource'))
        match = re.search(r'/payments/(\d+)', resource)
        if match:
            payment_id = match.group(1)
    if not payment_id:
        return
    if payment_id in getattr(process_mercadopago_webhook, '_processed', set()):
        return
    setattr(process_mercadopago_webhook, '_processed', getattr(process_mercadopago_webhook, '_processed', set()) | {payment_id})
    payment_data = get_mercadopago_payment(payment_id)
    if not payment_data:
        return
    deposit_id = payment_data.get('external_reference') or payment_data.get('metadata', {}).get('external_reference')
    if not deposit_id:
        return
    deposit = DEX_MANTES_DEPOSITS.get(str(deposit_id))
    if deposit is None:
        return
    if deposit.get('payment_id') and str(deposit.get('payment_id')) != str(payment_id):
        return
    payment_status = str(payment_data.get('status', '')).lower()
    payment_detail = str(payment_data.get('status_detail', '')).lower()

    if payment_status == 'approved':
        if deposit.get('status') == 'PAID':
            return
        if deposit.get('mercadopago_payment_id') and str(deposit.get('mercadopago_payment_id')) != str(payment_id):
            return
        expected_brl = _to_decimal(deposit.get('amount_brl', '0'))
        received_brl = _to_decimal(payment_data.get('transaction_amount', '0'))
        if abs(received_brl - expected_brl) > Decimal('0.01'):
            return
        user_id = int(deposit.get('user_id'))
        previous_balance = get_dex_mantes_balance(user_id)
        new_balance = previous_balance + _to_decimal(deposit.get('dex_mantes_amount'))
        set_dex_mantes_balance(user_id, new_balance)
        update_deposit_status(str(deposit_id), 'PAID', payment_id=payment_id)
        user = bot.get_user(user_id)
        if user is not None:
            embed = discord.Embed(title='✅ DEPÓSITO CONFIRMADO', description='Seu pagamento foi aprovado pelo Mercado Pago.', color=0x22C55E)
            embed.add_field(name='Você recebeu', value=f'🔷 +{format_decimal_br(deposit["dex_mantes_amount"])} Dex Mantes', inline=False)
            embed.add_field(name='Saldo atual', value=f'🔷 {format_decimal_br(new_balance)} Dex Mantes', inline=False)
            try:
                loop = bot.loop
                if loop and loop.is_running():
                    asyncio.run_coroutine_threadsafe(user.send(embed=embed), loop)
            except Exception:
                pass
        return

    is_refund_event = payment_status in {'refunded', 'charged_back'} or payment_detail in {'refunded', 'chargeback'} or (
        payment_status == 'cancelled' and deposit.get('status') == 'PAID'
    )
    if not is_refund_event:
        return

    if deposit.get('status') in {'REFUNDED', 'CHARGED_BACK'} or deposit.get('refunded_at'):
        return
    if deposit.get('status') != 'PAID':
        return

    apply_deposit_refund(str(deposit_id), payment_id=payment_id, reason=f'mercadopago:{payment_status}:{payment_detail or ""}')


def ensure_mercadopago_webhook_server():
    global MERCADO_PAGO_WEBHOOK_SERVER
    if MERCADO_PAGO_WEBHOOK_SERVER is not None:
        return MERCADO_PAGO_WEBHOOK_SERVER
    host = os.getenv('MERCADO_PAGO_WEBHOOK_HOST', MERCADO_PAGO_WEBHOOK_HOST)
    port = int(os.getenv('MERCADO_PAGO_WEBHOOK_PORT', str(MERCADO_PAGO_WEBHOOK_PORT)))
    try:
        server = ThreadingHTTPServer((host, port), MercadoPagoWebhookHandler)
        MERCADO_PAGO_WEBHOOK_SERVER = server
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        return server
    except Exception:
        return None


_load_dex_mantes()
_load_deposits()


def get_balance(user_id: int) -> int:
    user_key = str(user_id)
    if user_key not in DEX_COINS:
        DEX_COINS[user_key] = 0
        _save_balances()
    return int(DEX_COINS[user_key])


def set_balance(user_id: int, value: int) -> int:
    user_key = str(user_id)
    DEX_COINS[user_key] = max(0, int(value))
    _save_balances()
    return DEX_COINS[user_key]


def get_daily_claim_remaining(user_id: int):
    profile = get_profile(user_id)
    last_claim = profile.get('last_daily_claim')
    if not last_claim:
        return None
    try:
        last_dt = datetime.fromisoformat(last_claim)
    except Exception:
        return None
    if last_dt.tzinfo is None:
        last_dt = last_dt.replace(tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    remaining = (last_dt + timedelta(hours=24)) - now
    if remaining.total_seconds() <= 0:
        return None
    return remaining


def claim_daily_bonus(user_id: int):
    profile = get_profile(user_id)
    now = datetime.now(timezone.utc)
    last_claim = profile.get('last_daily_claim')
    if last_claim:
        try:
            last_dt = datetime.fromisoformat(last_claim)
            if last_dt.tzinfo is None:
                last_dt = last_dt.replace(tzinfo=timezone.utc)
            if now - last_dt < timedelta(hours=24):
                remaining = (last_dt + timedelta(hours=24)) - now
                return {
                    'ok': False,
                    'remaining': remaining,
                    'message': '⏳ Diário indisponível\nVocê já resgatou suas Dex Coins diárias.\nPróximo resgate em: ' + str(timedelta(seconds=max(remaining.total_seconds(), 0)))
                }
        except Exception:
            pass
    with _DATA_LOCK:
        profile = get_profile(user_id)
        now = datetime.now(timezone.utc)
        last_claim = profile.get('last_daily_claim')
        if last_claim:
            try:
                last_dt = datetime.fromisoformat(last_claim)
                if last_dt.tzinfo is None:
                    last_dt = last_dt.replace(tzinfo=timezone.utc)
                if now - last_dt < timedelta(hours=24):
                    remaining = (last_dt + timedelta(hours=24)) - now
                    return {
                        'ok': False,
                        'remaining': remaining,
                        'message': '⏳ Diário indisponível\nVocê já resgatou suas Dex Coins diárias.\nPróximo resgate em: ' + str(timedelta(seconds=max(remaining.total_seconds(), 0)))
                    }
            except Exception:
                pass
        balance = get_balance(user_id)
        new_balance = balance + 100
        DEX_COINS[str(user_id)] = max(0, int(new_balance))
        _save_balances()
        profile['last_daily_claim'] = now.isoformat()
        _save_profiles()
        return {
            'ok': True,
            'amount': 100,
            'balance': new_balance,
            'message': '🎁 Diário resgatado!\n+100 Dex Coins\nSaldo atual: ' + str(new_balance) + ' Dex Coins'
        }


def get_percent_value(user_id: int) -> int:
    saldo = get_balance(user_id)
    if saldo <= 0:
        return 0
    valor = math.floor(saldo * 0.01)
    if valor <= 0:
        return 0
    return valor


def roll_symbols():
    return [random.choice(SYMBOLS) for _ in range(3)]


def get_slot_result(symbols):
    counts = {symbol: symbols.count(symbol) for symbol in set(symbols)}

    if len(counts) == 1:
        symbol = next(iter(counts))
        return {
            'result': 'trinca',
            'emoji': symbol,
            'message': '🎉 TRINCA!',
            'multiplier': MULTIPLIERS[symbol],
        }

    if any(count == 2 for count in counts.values()):
        return {
            'result': 'dupla',
            'emoji': None,
            'message': '↩️ Devolução da aposta',
            'multiplier': 1,
        }

    return {
        'result': 'perdeu',
        'emoji': None,
        'message': '❌ Você perdeu!',
        'multiplier': 0,
    }


def calculate_scratch_result(symbols, aposta: int):
    counts = Counter(symbols)
    maior_repeticao = max(counts.values(), default=0)

    if maior_repeticao < 3:
        return {
            'count': maior_repeticao,
            'message': '❌ Perdeu a raspadinha.',
            'headline': '❌ Perdeu a raspadinha.',
            'total_return': 0,
            'profit': 0,
            'final_text': 'Aposta perdida',
            'perfect': False,
        }

    if maior_repeticao == 9:
        total_return = int(aposta * 2.30)
        return {
            'count': 9,
            'message': '🎉 RASPADINHA PERFEITA!',
            'headline': '🎉 9 iguais!',
            'total_return': total_return,
            'profit': total_return - aposta,
            'final_text': f'Total recebido: `{total_return} Dex Coins`',
            'perfect': True,
        }

    if maior_repeticao == 3:
        return {
            'count': 3,
            'message': '↩️ Aposta devolvida',
            'headline': '3 iguais',
            'total_return': aposta,
            'profit': 0,
            'final_text': f'Retorno: `{aposta} Dex Coins`',
            'perfect': False,
        }

    percent = SCRATCH_REWARD_TABLE[maior_repeticao]
    total_return = int(math.floor(aposta * (1 + percent)))
    return {
        'count': maior_repeticao,
        'message': f'🎉 {maior_repeticao} iguais!',
        'headline': f'🎉 {maior_repeticao} iguais!',
        'total_return': total_return,
        'profit': total_return - aposta,
        'final_text': f'Retorno: `{total_return} Dex Coins`',
        'perfect': False,
    }


class BackToMenuView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='↩️ Voltar ao menu', style=discord.ButtonStyle.blurple, custom_id='menu_back')
    async def voltar_ao_menu(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('Menu social:', view=MenuView(), ephemeral=True)


PROFILE_DATA_FILE = os.path.join(DATA_DIR, 'profiles.json')
PROFILES = {}
TRANSFER_CONFIRMATIONS = {}


def _load_profiles():
    try:
        if os.path.isfile(PROFILE_DATA_FILE):
            with open(PROFILE_DATA_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            for k, v in data.items():
                PROFILES[str(k)] = v
    except Exception:
        PROFILES.clear()


def _save_profiles():
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        tmp = PROFILE_DATA_FILE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(PROFILES, f, ensure_ascii=False, indent=2)
        os.replace(tmp, PROFILE_DATA_FILE)
    except Exception:
        pass


_load_profiles()


def get_profile(user_id: int):
    key = str(user_id)
    if key not in PROFILES:
        PROFILES[key] = {
            'user_id': key,
            'profile_nickname': '',
            'profile_bio': '',
            'profile_avatar_url': '',
            'profile_banner_url': '',
            'banner_expires_at': None,
            'vip_expires_at': None,
            'last_daily_claim': None,
            'created_at': datetime.now(timezone.utc).isoformat(),
        }
        _save_profiles()
    return PROFILES[key]


def is_valid_url(url: str) -> bool:
    if not isinstance(url, str):
        return False
    value = url.strip()
    if not value:
        return False
    parsed = urlparse(value)
    return parsed.scheme in {'http', 'https'} and bool(parsed.netloc)


def format_profile_name(user_id: int, user=None):
    profile = get_profile(user_id)
    custom = (profile.get('profile_nickname') or '').strip()
    if custom:
        return custom
    if user is not None:
        if getattr(user, 'display_name', None):
            return user.display_name
        if getattr(user, 'global_name', None):
            return user.global_name
        if getattr(user, 'name', None):
            return user.name
    return 'Usuário'


def profile_avatar_url(user_id: int, member=None, fallback_user=None):
    profile = get_profile(user_id)
    custom = (profile.get('profile_avatar_url') or '').strip()
    if custom and is_valid_url(custom):
        return custom
    if member is not None and member.avatar:
        return member.avatar.url
    if fallback_user is not None and fallback_user.avatar:
        return fallback_user.avatar.url
    return None


def get_discord_original_bio(target_user=None):
    if target_user is None:
        return ''
    bio = getattr(target_user, 'bio', None)
    if isinstance(bio, str):
        cleaned = bio.strip()
        if cleaned:
            return cleaned
    return ''


def get_discord_original_banner_url(target_user=None, member=None):
    candidates = []
    if member is not None:
        candidates.append(getattr(member, 'banner', None))
        candidates.append(getattr(member, 'guild_banner', None))
    if target_user is not None:
        candidates.append(getattr(target_user, 'banner', None))
    for banner in candidates:
        if banner is None:
            continue
        url = getattr(banner, 'url', None)
        if url:
            return url
    return None


def get_profile_bio(user_id: int, target_user=None):
    profile = get_profile(user_id)
    custom = (profile.get('profile_bio') or '').strip()
    if custom:
        return custom
    return get_discord_original_bio(target_user)


def get_profile_banner_url(user_id: int, target_user=None, member=None):
    profile = get_profile(user_id)
    custom = (profile.get('profile_banner_url') or '').strip()
    if custom and banner_is_active(profile):
        return custom
    return get_discord_original_banner_url(target_user=target_user, member=member)


def banner_is_active(profile):
    if not profile:
        return False
    expires = profile.get('banner_expires_at')
    if not expires:
        return False
    try:
        expires_dt = datetime.fromisoformat(expires)
    except Exception:
        return False
    return datetime.now(timezone.utc) < expires_dt


def build_profile_embed(target_user_id: int, viewer_user_id: int):
    target_user = bot.get_user(target_user_id)
    member = None
    if bot.guilds:
        for guild in bot.guilds:
            member = guild.get_member(target_user_id)
            if member is not None:
                break

    profile = get_profile(target_user_id)
    display_name = format_profile_name(target_user_id, member or target_user)
    title = '👤 PERFIL' if viewer_user_id == target_user_id else f'👤 PERFIL DE {display_name.upper()}'
    embed = discord.Embed(title=title, color=0x8B5CF6)
    mention = target_user.mention if target_user else '@usuario'
    embed.add_field(name='Nome', value=f'{display_name}\n{mention}', inline=False)
    embed.add_field(name='🪙 Dex Coins', value=f'{format_integer_br(get_balance(target_user_id))} 🪙', inline=False)
    embed.add_field(name='🔷 Dex Mantes', value=f'{format_decimal_br(get_dex_mantes_balance(target_user_id))} 🔷', inline=False)
    if is_vip_active(target_user_id):
        expires = get_vip_expiration(target_user_id)
        if expires:
            embed.add_field(name='💎 VIP', value=f'Ativo até {expires.strftime("%d/%m/%Y")}', inline=False)
    bio = get_profile_bio(target_user_id, target_user) or 'Nenhuma bio definida.'
    embed.add_field(name='📝 Bio', value=bio[:200], inline=False)

    created_at = profile.get('created_at')
    if created_at:
        try:
            created_dt = datetime.fromisoformat(created_at)
            embed.add_field(name='📅 Membro desde', value=created_dt.strftime('%d/%m/%Y'), inline=False)
        except Exception:
            pass

    avatar_url = profile_avatar_url(target_user_id, member=member, fallback_user=target_user)
    if avatar_url:
        embed.set_thumbnail(url=avatar_url)

    banner_url = get_profile_banner_url(target_user_id, target_user=target_user, member=member)
    if banner_url:
        embed.set_image(url=banner_url)

    return embed


def get_vip_expiration(user_id: int):
    expires = get_profile(user_id).get('vip_expires_at')
    if not expires:
        return None
    try:
        expires_dt = datetime.fromisoformat(expires)
        if expires_dt.tzinfo is None:
            expires_dt = expires_dt.replace(tzinfo=timezone.utc)
        return expires_dt
    except Exception:
        return None


def is_vip_active(user_id: int) -> bool:
    expires = get_vip_expiration(user_id)
    if expires is None:
        return False
    return datetime.now(timezone.utc) < expires


def get_vip_status(user_id: int):
    expires = get_vip_expiration(user_id)
    return {
        'active': is_vip_active(user_id),
        'expires_at': expires,
    }


def activate_vip(user_id: int):
    with _DATA_LOCK:
        profile = get_profile(user_id)
        now = datetime.now(timezone.utc)
        current_exp = get_vip_expiration(user_id)
        balance = get_dex_mantes_balance(user_id)
        required = Decimal('1.00')
        if balance < required:
            return {
                'ok': False,
                'reason': 'insufficient_balance',
                'required': required,
                'current': balance,
                'message': '❌ **Dex Mantes insuficientes**\nVocê precisa de:\n**🔷 1,00 Dex Mantes**\nSeu saldo:\n**🔷 ' + format_decimal_br(balance) + ' Dex Mantes**',
            }
        if current_exp is not None and now < current_exp:
            new_exp = current_exp + timedelta(days=30)
        else:
            new_exp = now + timedelta(days=30)
        profile['vip_expires_at'] = new_exp.isoformat()
        _save_profiles()
        set_dex_mantes_balance(user_id, balance - required)
        return {
            'ok': True,
            'expires_at': new_exp,
            'balance': get_dex_mantes_balance(user_id),
        }


def build_vip_purchase_embed(user_id: int):
    balance = get_dex_mantes_balance(user_id)
    embed = discord.Embed(title='💎 DEXTROIER VIP', description='Tenha acesso às funções exclusivas do VIP.', color=0x8B5CF6)
    embed.add_field(name='🔷 Preço', value='**1 Dex Mantes**', inline=False)
    embed.add_field(name='📅 Duração', value='**30 dias**', inline=False)
    embed.add_field(name='🔷 Seu saldo', value=f'`{format_decimal_br(balance)}`', inline=False)
    embed.add_field(name='Ação', value='Deseja ativar o VIP?', inline=False)
    return embed


def build_vip_active_embed(user_id: int):
    expires = get_vip_expiration(user_id)
    embed = discord.Embed(title='💎 DEXTROIER VIP', description='🟢 **VIP ativo**', color=0x8B5CF6)
    if expires:
        embed.add_field(name='📅 Expira em', value=f'`{expires.strftime("%d/%m/%Y")}`', inline=False)
    embed.add_field(name='Escolha uma função', value='Selecione abaixo.', inline=False)
    return embed


class VIPPurchaseView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='💎 Ativar VIP — 1 🔷', style=discord.ButtonStyle.primary, custom_id='vip_activate')
    async def ativar(self, interaction: discord.Interaction, button: discord.ui.Button):
        user_id = interaction.user.id
        if is_vip_active(user_id):
            await interaction.response.send_message(embed=build_vip_active_embed(user_id), view=VIPActiveView(), ephemeral=True)
            return
        result = activate_vip(user_id)
        if not result['ok']:
            await interaction.response.send_message(result['message'], ephemeral=True)
            return
        await interaction.response.send_message(embed=build_vip_active_embed(user_id), view=VIPActiveView(), ephemeral=True)

    @discord.ui.button(label='❌ Cancelar', style=discord.ButtonStyle.danger, custom_id='vip_cancel')
    async def cancelar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title='🎮 Dextroier', description='Escolha uma opção abaixo.', color=0x8B5CF6)
        await interaction.response.send_message(embed=embed, view=MenuView(), ephemeral=True)


class VIPActiveView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='🤖 Usar AI', style=discord.ButtonStyle.blurple, custom_id='vip_ai_main')
    async def usar_ai(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_vip_active(interaction.user.id):
            await interaction.response.send_message('❌ **Seu VIP expirou.**\n\nRenove o VIP para continuar utilizando a AI.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_vip_ai_menu_embed(interaction.user.id), view=VIPAIMenuView(), ephemeral=True)

    @discord.ui.button(label='💎 Funções VIP', style=discord.ButtonStyle.blurple, custom_id='vip_functions')
    async def funcoes(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_vip_active(interaction.user.id):
            await interaction.response.send_message('❌ Seu VIP expirou.\n\n[💎 Renovar VIP — 1 🔷]', ephemeral=True)
            await interaction.followup.send(embed=build_vip_purchase_embed(interaction.user.id), view=VIPPurchaseView(), ephemeral=True)
            return
        embed = discord.Embed(title='💎 FUNÇÕES VIP', description='Recursos exclusivos do VIP do Dextroier.', color=0x8B5CF6)
        await interaction.response.send_message(embed=embed, view=VIPFeaturesView(), ephemeral=True)

    @discord.ui.button(label='ℹ️ Informações VIP', style=discord.ButtonStyle.grey, custom_id='vip_info')
    async def info(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_vip_active(interaction.user.id):
            await interaction.response.send_message('❌ Seu VIP expirou.\n\n**[💎 Renovar VIP — 1 🔷]**', ephemeral=True)
            return
        expires = get_vip_expiration(interaction.user.id)
        embed = discord.Embed(title='ℹ️ INFORMAÇÕES VIP', description='Dados do plano VIP do Dextroier.', color=0x8B5CF6)
        embed.add_field(name='📅 Expira em', value=f'`{expires.strftime("%d/%m/%Y")}`', inline=False)
        embed.add_field(name='🔷 Valor', value='1 Dex Mantes', inline=False)
        embed.add_field(name='📆 Duração', value='30 dias', inline=False)
        await interaction.response.send_message(embed=embed, view=VIPActiveView(), ephemeral=True)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='vip_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title='🎮 Dextroier', description='Escolha uma opção abaixo.', color=0x8B5CF6)
        await interaction.response.send_message(embed=embed, view=MenuView(), ephemeral=True)


class VIPFeaturesView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='vip_features_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_vip_active(interaction.user.id):
            await interaction.response.send_message('❌ Seu VIP expirou.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_vip_active_embed(interaction.user.id), view=VIPActiveView(), ephemeral=True)


class VIPMenuView(discord.ui.View):
    def __init__(self, user_id: int):
        super().__init__(timeout=180)
        self.user_id = user_id

    async def _show_menu(self, interaction: discord.Interaction):
        if is_vip_active(self.user_id):
            await interaction.response.send_message(embed=build_vip_active_embed(self.user_id), view=VIPActiveView(), ephemeral=True)
            return
        await interaction.response.send_message(embed=build_vip_purchase_embed(self.user_id), view=VIPPurchaseView(), ephemeral=True)

    @discord.ui.button(label='💎 VIP Menu', style=discord.ButtonStyle.primary, custom_id='vip_menu_screen')
    async def abrir(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._show_menu(interaction)


class NicknameModal(discord.ui.Modal):
    def __init__(self, user_id: int):
        super().__init__(title='✏️ Alterar apelido')
        self.user_id = user_id
        self.nickname = discord.ui.TextInput(
            label='Apelido interno',
            placeholder='Ex: Dex',
            min_length=1,
            max_length=20,
            required=True,
        )
        self.add_item(self.nickname)

    async def on_submit(self, interaction: discord.Interaction):
        value = self.nickname.value.strip()
        if not value:
            await interaction.response.send_message('❌ Apelido inválido.', ephemeral=True)
            return
        profile = get_profile(self.user_id)
        profile['profile_nickname'] = value[:20]
        _save_profiles()
        await interaction.response.send_message(f'✅ Apelido atualizado para `{value[:20]}`.', ephemeral=True)


class BioModal(discord.ui.Modal):
    def __init__(self, user_id: int):
        super().__init__(title='📝 Alterar bio')
        self.user_id = user_id
        self.bio = discord.ui.TextInput(
            label='Sua bio',
            placeholder='Ex: Gosto de jogar e estou tentando ficar rico em Dex Coins.',
            min_length=1,
            max_length=200,
            required=True,
            style=discord.TextStyle.long,
        )
        self.add_item(self.bio)

    async def on_submit(self, interaction: discord.Interaction):
        value = self.bio.value.strip()
        sanitized = value.replace('@everyone', '@ everyone').replace('@here', '@ here')
        profile = get_profile(self.user_id)
        profile['profile_bio'] = sanitized[:200]
        _save_profiles()
        await interaction.response.send_message('✅ Bio atualizada.', ephemeral=True)


class ProfileURLModal(discord.ui.Modal):
    def __init__(self, user_id: int, field_name: str, title: str):
        super().__init__(title=title)
        self.user_id = user_id
        self.field_name = field_name
        self.url_field = discord.ui.TextInput(
            label='URL da imagem',
            placeholder='https://exemplo.com/imagem.png',
            min_length=8,
            max_length=500,
            required=True,
        )
        self.add_item(self.url_field)

    async def on_submit(self, interaction: discord.Interaction):
        value = self.url_field.value.strip()
        if not is_valid_url(value):
            await interaction.response.send_message('❌ URL inválida. Use uma URL HTTP/HTTPS válida.', ephemeral=True)
            return
        profile = get_profile(self.user_id)
        profile[self.field_name] = value
        _save_profiles()
        await interaction.response.send_message('✅ URL salva com sucesso.', ephemeral=True)


class BannerModal(discord.ui.Modal):
    def __init__(self, user_id: int, mode: str):
        super().__init__(title='🎨 Configurar Banner' if mode == 'activate' else '🎨 Alterar Banner')
        self.user_id = user_id
        self.mode = mode
        self.url_field = discord.ui.TextInput(
            label='URL do Banner' if mode == 'activate' else 'Nova URL do Banner',
            placeholder='https://exemplo.com/banner.png',
            min_length=8,
            max_length=500,
            required=True,
        )
        self.add_item(self.url_field)

    async def on_submit(self, interaction: discord.Interaction):
        value = self.url_field.value.strip()
        if not is_valid_url(value):
            await interaction.response.send_message('❌ URL inválida. Use uma URL HTTP/HTTPS válida.', ephemeral=True)
            return

        profile = get_profile(self.user_id)
        if self.mode == 'activate':
            custo = 500
            if get_balance(self.user_id) < custo:
                await interaction.response.send_message('❌ Você não possui saldo suficiente para ativar o banner (500 Dex Coins).', ephemeral=True)
                return
            saldo_atual = get_balance(self.user_id)
            set_balance(self.user_id, saldo_atual - custo)
            profile['profile_banner_url'] = value
            profile['banner_expires_at'] = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
            _save_profiles()
            await interaction.response.send_message(
                '✅ Banner ativado!\nCusto: `500 Dex Coins`\nValidade: `30 dias`',
                ephemeral=True,
            )
            return

        profile['profile_banner_url'] = value
        if profile.get('banner_expires_at'):
            try:
                expires_dt = datetime.fromisoformat(profile['banner_expires_at'])
                if datetime.now(timezone.utc) < expires_dt:
                    remaining = max(0.0, (expires_dt - datetime.now(timezone.utc)).total_seconds())
                    new_dt = datetime.now(timezone.utc) + timedelta(seconds=remaining) + timedelta(days=30)
                    profile['banner_expires_at'] = new_dt.isoformat()
                else:
                    profile['banner_expires_at'] = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
            except Exception:
                profile['banner_expires_at'] = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
        else:
            profile['banner_expires_at'] = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
        _save_profiles()
        await interaction.response.send_message('✅ Banner atualizado com sucesso.', ephemeral=True)


def build_banner_menu_embed(user_id: int, profile):
    active = banner_is_active(profile)
    if active:
        expires = profile.get('banner_expires_at')
        expires_txt = 'Indefinido'
        if expires:
            try:
                expires_dt = datetime.fromisoformat(expires)
                expires_txt = expires_dt.strftime('%d/%m/%Y')
            except Exception:
                expires_txt = 'Indefinido'
        embed = discord.Embed(
            title='🎨 Seu Banner',
            description='🟢 **Status:** Ativo\n\n📅 **Expira em:** ' + expires_txt + '\n\n🪙 **Renovação:** 500 Dex Coins / 30 dias',
            color=0x8B5CF6,
        )
        return embed

    embed = discord.Embed(
        title='🎨 Banner Personalizado',
        description='Dê um visual diferente ao seu perfil.',
        color=0x8B5CF6,
    )
    embed.add_field(name='💰 Custo', value='500 Dex Coins', inline=False)
    embed.add_field(name='⏳ Duração', value='30 dias de duração', inline=False)
    embed.add_field(name='🪙 Seu saldo', value=f'{get_balance(user_id)} Dex Coins', inline=False)
    return embed


class BannerManagementView(discord.ui.View):
    def __init__(self, user_id: int, profile):
        super().__init__(timeout=180)
        self.user_id = user_id
        active = banner_is_active(profile)

        buttons = []
        if active:
            buttons.append(('🖼️ Alterar Banner', discord.ButtonStyle.blurple, 'banner_change'))
            buttons.append(('🔄 Renovar — 500 Dex Coins', discord.ButtonStyle.green, 'banner_renew'))
            buttons.append(('🗑️ Remover Banner', discord.ButtonStyle.danger, 'banner_remove'))
        else:
            buttons.append(('🎨 Comprar Banner', discord.ButtonStyle.blurple, 'banner_activate'))

        buttons.append(('↩️ Voltar', discord.ButtonStyle.secondary, 'banner_back'))

        for label, style, custom_id in buttons:
            button = discord.ui.Button(label=label, style=style, custom_id=custom_id)
            button.callback = lambda interaction, custom_id=custom_id: self._handle(interaction, custom_id)
            self.add_item(button)

    @staticmethod
    async def _handle(interaction: discord.Interaction, label: str):
        profile = get_profile(interaction.user.id)
        if label == 'banner_activate':
            if get_balance(interaction.user.id) < 500:
                await interaction.response.send_message('❌ Saldo insuficiente. O banner custa 500 Dex Coins.', ephemeral=True)
                return
            await interaction.response.send_modal(BannerModal(interaction.user.id, 'activate'))
            return
        if label == 'banner_change':
            await interaction.response.send_modal(BannerModal(interaction.user.id, 'update'))
            return
        if label == 'banner_renew':
            if get_balance(interaction.user.id) < 500:
                await interaction.response.send_message('❌ Saldo insuficiente para renovar o banner.', ephemeral=True)
                return
            saldo = get_balance(interaction.user.id)
            set_balance(interaction.user.id, saldo - 500)
            expires = profile.get('banner_expires_at')
            now = datetime.now(timezone.utc)
            if expires:
                try:
                    expires_dt = datetime.fromisoformat(expires)
                    remaining = max(0.0, (expires_dt - now).total_seconds())
                    new_dt = now + timedelta(seconds=remaining) + timedelta(days=30)
                    profile['banner_expires_at'] = new_dt.isoformat()
                except Exception:
                    profile['banner_expires_at'] = (now + timedelta(days=30)).isoformat()
            else:
                profile['banner_expires_at'] = (now + timedelta(days=30)).isoformat()
            _save_profiles()
            await interaction.response.send_message('✅ Banner renovado com sucesso.', ephemeral=True)
            return
        if label == 'banner_remove':
            profile['profile_banner_url'] = ''
            profile['banner_expires_at'] = None
            _save_profiles()
            await interaction.response.send_message('✅ Banner removido.', ephemeral=True)
            return
        if label == 'banner_back':
            embed = discord.Embed(
                title='⚙️ Personalizar Perfil',
                description='Configure a aparência do seu perfil dentro do bot.\n\nEscolha o que deseja alterar:',
                color=0x8B5CF6,
            )
            await interaction.response.send_message(embed=embed, view=ProfileCustomizationView(), ephemeral=True)


class OtherProfileSelect(discord.ui.UserSelect):
    def __init__(self):
        super().__init__(placeholder='👤 Selecionar Usuário', min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        selected = self.values[0]
        embed = build_profile_embed(selected.id, interaction.user.id)
        await interaction.response.send_message(embed=embed, ephemeral=True)


class OtherProfileView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.add_item(OtherProfileSelect())

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='other_profile_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title='👤 Perfil',
            description='Personalize seu perfil ou veja o perfil de outro usuário.\n\nEscolha uma opção abaixo.',
            color=0x8B5CF6,
        )
        await interaction.response.send_message(embed=embed, view=ProfileView(), ephemeral=True)


class ProfileManagementView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='⚙️ Personalizar Perfil', style=discord.ButtonStyle.blurple, custom_id='profile_customize')
    async def personalizar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title='⚙️ Personalizar Perfil',
            description='Configure a aparência do seu perfil dentro do bot.\n\nEscolha o que deseja alterar:',
            color=0x8B5CF6,
        )
        await interaction.response.send_message(embed=embed, view=ProfileCustomizationView(), ephemeral=True)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='profile_back_to_menu')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title='🎮 Menu Social',
            description='Escolha uma opção abaixo.',
            color=0x8B5CF6,
        )
        await interaction.response.send_message(embed=embed, view=MenuView(), ephemeral=True)


class ProfileCustomizationView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='✏️ Apelido', style=discord.ButtonStyle.blurple, custom_id='profile_nickname')
    async def alterar_apelido(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(NicknameModal(interaction.user.id))

    @discord.ui.button(label='📝 Bio', style=discord.ButtonStyle.blurple, custom_id='profile_bio')
    async def alterar_bio(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(BioModal(interaction.user.id))

    @discord.ui.button(label='🗑️ Remover Bio', style=discord.ButtonStyle.danger, custom_id='profile_bio_remove')
    async def remover_bio(self, interaction: discord.Interaction, button: discord.ui.Button):
        profile = get_profile(interaction.user.id)
        profile['profile_bio'] = ''
        _save_profiles()
        await interaction.response.send_message('✅ Bio removida. O perfil voltou ao padrão.', ephemeral=True)

    @discord.ui.button(label='🖼️ Avatar', style=discord.ButtonStyle.blurple, custom_id='profile_avatar')
    async def alterar_avatar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(ProfileURLModal(interaction.user.id, 'profile_avatar_url', '🖼️ Avatar Personalizado'))

    @discord.ui.button(label='🗑️ Remover Avatar', style=discord.ButtonStyle.danger, custom_id='profile_avatar_remove')
    async def remover_avatar(self, interaction: discord.Interaction, button: discord.ui.Button):
        profile = get_profile(interaction.user.id)
        profile['profile_avatar_url'] = ''
        _save_profiles()
        await interaction.response.send_message('✅ Avatar personalizado removido. O avatar do Discord será usado novamente.', ephemeral=True)

    @discord.ui.button(label='🎨 Banner', style=discord.ButtonStyle.blurple, custom_id='profile_banner')
    async def banner(self, interaction: discord.Interaction, button: discord.ui.Button):
        profile = get_profile(interaction.user.id)
        embed = build_banner_menu_embed(interaction.user.id, profile)
        await interaction.response.send_message(embed=embed, view=BannerManagementView(interaction.user.id, profile), ephemeral=True)

    @discord.ui.button(label='🗑️ Remover Personalizações', style=discord.ButtonStyle.danger, custom_id='profile_remove_all')
    async def remover_personalizacoes(self, interaction: discord.Interaction, button: discord.ui.Button):
        profile = get_profile(interaction.user.id)
        profile['profile_nickname'] = ''
        profile['profile_bio'] = ''
        profile['profile_avatar_url'] = ''
        profile['profile_banner_url'] = ''
        profile['banner_expires_at'] = None
        _save_profiles()
        await interaction.response.send_message('✅ Personalizações removidas. O perfil voltou ao padrão.', ephemeral=True)

    @discord.ui.button(label='👁️ Visualizar Perfil', style=discord.ButtonStyle.grey, custom_id='profile_view')
    async def visualizar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = build_profile_embed(interaction.user.id, interaction.user.id)
        await interaction.response.send_message(embed=embed, view=ProfileManagementView(), ephemeral=True)

    @discord.ui.button(label='↩️ Voltar ao Perfil', style=discord.ButtonStyle.secondary, custom_id='profile_customize_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = build_profile_embed(interaction.user.id, interaction.user.id)
        await interaction.response.send_message(embed=embed, view=ProfileManagementView(), ephemeral=True)


class ProfileView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='👤 Meu Perfil', style=discord.ButtonStyle.blurple, custom_id='profile_self')
    async def meu_perfil(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = build_profile_embed(interaction.user.id, interaction.user.id)
        await interaction.response.send_message(embed=embed, view=ProfileManagementView(), ephemeral=True)

    @discord.ui.button(label='👥 Outro Perfil', style=discord.ButtonStyle.blurple, custom_id='profile_other')
    async def outro_perfil(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title='👥 Ver Outro Perfil',
            description='Selecione uma pessoa para visualizar o perfil.',
            color=0x8B5CF6,
        )
        await interaction.response.send_message(embed=embed, view=OtherProfileView(), ephemeral=True)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='profile_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title='🎮 Menu Social',
            description='Escolha uma opção abaixo.',
            color=0x8B5CF6,
        )
        await interaction.response.send_message(embed=embed, view=MenuView(), ephemeral=True)


class TransferAmountModal(discord.ui.Modal):
    def __init__(self, sender_id: int, recipient_id: int, recipient_mention: str):
        super().__init__(title='💸 Transferir Dex Coins')
        self.sender_id = sender_id
        self.recipient_id = recipient_id
        self.recipient_mention = recipient_mention
        self.amount = discord.ui.TextInput(
            label='Quantidade',
            placeholder='Digite a quantidade de Dex Coins',
            min_length=1,
            max_length=12,
            required=True,
        )
        self.add_item(self.amount)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            amount = int(self.amount.value.strip())
        except ValueError:
            await interaction.response.send_message('❌ Quantidade inválida. Digite um número inteiro maior que zero.', ephemeral=True)
            return
        if amount <= 0:
            await interaction.response.send_message('❌ A quantidade deve ser maior que zero.', ephemeral=True)
            return
        if interaction.user.id == self.recipient_id:
            await interaction.response.send_message('❌ Você não pode transferir Dex Coins para si mesmo.', ephemeral=True)
            return
        sender_balance = get_balance(interaction.user.id)
        if amount > sender_balance:
            await interaction.response.send_message('❌ Saldo insuficiente para essa transferência.', ephemeral=True)
            return
        new_balance = sender_balance - amount
        embed = discord.Embed(title='💸 Confirmar Transferência', color=0x8B5CF6)
        embed.add_field(name='Você está enviando', value=f'**{amount} Dex Coins**', inline=False)
        embed.add_field(name='Para', value=f'**{self.recipient_mention}**', inline=False)
        embed.add_field(name='Seu saldo após a transferência', value=f'**{new_balance} Dex Coins**', inline=False)
        transfer_key = f'{interaction.user.id}:{self.recipient_id}:{amount}'
        TRANSFER_CONFIRMATIONS[transfer_key] = True
        await interaction.response.send_message(embed=embed, view=TransferConfirmView(interaction.user.id, self.recipient_id, amount, self.recipient_mention), ephemeral=True)


class TransferConfirmView(discord.ui.View):
    def __init__(self, sender_id: int, recipient_id: int, amount: int, recipient_mention: str):
        super().__init__(timeout=180)
        self.sender_id = sender_id
        self.recipient_id = recipient_id
        self.amount = amount
        self.recipient_mention = recipient_mention

    @discord.ui.button(label='✅ Confirmar', style=discord.ButtonStyle.success, custom_id='transfer_confirm')
    async def confirmar(self, interaction: discord.Interaction, button: discord.ui.Button):
        key = f'{interaction.user.id}:{self.recipient_id}:{self.amount}'
        with _DATA_LOCK:
            if key not in TRANSFER_CONFIRMATIONS:
                await interaction.response.send_message('❌ Esta transferência já foi processada ou cancelada.', ephemeral=True)
                return
            TRANSFER_CONFIRMATIONS.pop(key, None)
            sender_balance = get_balance(interaction.user.id)
            recipient_balance = get_balance(self.recipient_id)
            if interaction.user.id == self.recipient_id:
                await interaction.response.send_message('❌ Transferência inválida para o mesmo usuário.', ephemeral=True)
                return
            if self.amount <= 0 or sender_balance < self.amount:
                await interaction.response.send_message('❌ Transferência inválida. Saldo insuficiente.', ephemeral=True)
                return
            new_sender_balance = sender_balance - self.amount
            new_recipient_balance = recipient_balance + self.amount
            DEX_COINS[str(interaction.user.id)] = max(0, int(new_sender_balance))
            DEX_COINS[str(self.recipient_id)] = max(0, int(new_recipient_balance))
            _save_balances()
        await interaction.response.send_message(f'✅ Transferência realizada!\nVocê enviou {self.amount} Dex Coins para {self.recipient_mention}.', ephemeral=True)

    @discord.ui.button(label='❌ Cancelar', style=discord.ButtonStyle.danger, custom_id='transfer_cancel')
    async def cancelar(self, interaction: discord.Interaction, button: discord.ui.Button):
        key = f'{interaction.user.id}:{self.recipient_id}:{self.amount}'
        TRANSFER_CONFIRMATIONS.pop(key, None)
        await interaction.response.send_message('❌ Transferência cancelada.', ephemeral=True)


class TransferRecipientSelect(discord.ui.UserSelect):
    def __init__(self):
        super().__init__(placeholder='👤 Selecionar Usuário', min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        selected = self.values[0]
        if selected.id == interaction.user.id:
            await interaction.response.send_message('❌ Você não pode transferir Dex Coins para si mesmo.', ephemeral=True)
            return
        await interaction.response.send_modal(TransferAmountModal(interaction.user.id, selected.id, selected.mention))


class TransferView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.add_item(TransferRecipientSelect())

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='transfer_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title='⚡ Ação', description='Escolha uma opção abaixo.', color=0x8B5CF6)
        await interaction.response.send_message(embed=embed, view=ActionView(), ephemeral=True)


class BankView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='💳 Depositar', style=discord.ButtonStyle.blurple, custom_id='bank_deposit')
    async def depositar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_bank_deposit_embed(interaction.user.id), view=DepositView(), ephemeral=True)

    @discord.ui.button(label='💱 Câmbio', style=discord.ButtonStyle.primary, custom_id='bank_exchange')
    async def cambio(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_exchange_embed(interaction.user.id), view=ExchangeView(), ephemeral=True)

    @discord.ui.button(label='🤝 Brique', style=discord.ButtonStyle.green, custom_id='bank_brique')
    async def brique(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_brique_menu_embed(), view=BriqueUserSelectView(), ephemeral=True)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='bank_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title='⚡ Ação', description='Escolha uma opção abaixo.', color=0x8B5CF6)
        await interaction.response.send_message(embed=embed, view=ActionView(), ephemeral=True)


BRIQUE_PROPOSALS_FILE = os.path.join(DATA_DIR, 'brique_proposals.json')
BRIQUE_PROPOSALS = {}


def _load_brique_proposals():
    _ensure_data_dir()
    if not os.path.isfile(BRIQUE_PROPOSALS_FILE):
        return
    try:
        with open(BRIQUE_PROPOSALS_FILE, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        for key, value in data.items():
            BRIQUE_PROPOSALS[str(key)] = value
    except Exception:
        BRIQUE_PROPOSALS.clear()


def _save_brique_proposals():
    _ensure_data_dir()
    tmp = BRIQUE_PROPOSALS_FILE + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(BRIQUE_PROPOSALS, handle, ensure_ascii=False, indent=2)
        os.replace(tmp, BRIQUE_PROPOSALS_FILE)
    except Exception:
        if os.path.isfile(tmp):
            try:
                os.remove(tmp)
            except Exception:
                pass


_load_brique_proposals()


def _parse_brique_decimal(value):
    if value is None:
        return None
    text = str(value).strip().replace(' ', '').replace('.', '').replace(',', '.')
    if not text:
        return None
    try:
        decimal_value = Decimal(text)
    except InvalidOperation:
        return None
    return decimal_value


def _parse_brique_coin_value(value):
    text = str(value).strip().replace('.', '').replace(',', '')
    if not text:
        return None
    try:
        amount = int(text)
    except ValueError:
        return None
    return amount if amount > 0 else None


def _brique_minimum_valid(currency: str, value):
    if currency == 'coins':
        return value >= 1
    if currency == 'mantes':
        return value >= Decimal('0.01')
    return False


def _sanitize_decimal(value, digits=2):
    result = _to_decimal(value).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    if digits == 0:
        return int(result)
    return result


def build_exchange_embed(user_id: int):
    dex_coins = get_balance(user_id)
    dex_mantes = get_dex_mantes_balance(user_id)
    embed = discord.Embed(title='💱 CÂMBIO DEXTROIER', description='Troque suas moedas utilizando a taxa fixa.', color=0x8B5CF6)
    embed.add_field(name='🔷 1,00 Dex Mantes', value='=`🪙 1.000 Dex Coins`', inline=False)
    embed.add_field(name='🪙 1.000 Dex Coins', value='=`🔷 1,00 Dex Mantes`', inline=False)
    embed.add_field(name='💰 Seu saldo', value=f'🪙 Dex Coins: `{format_integer_br(dex_coins)}`\n🔷 Dex Mantes: `{format_decimal_br(dex_mantes)}`', inline=False)
    return embed


class DexMantesToCoinsModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title='💱 Converter Dex Mantes')
        self.amount = discord.ui.TextInput(
            label='Quantos 🔷 Dex Mantes deseja converter?',
            placeholder='Ex: 2.50',
            min_length=1,
            max_length=20,
            required=True,
        )
        self.add_item(self.amount)

    async def on_submit(self, interaction: discord.Interaction):
        amount = _parse_brique_decimal(self.amount.value)
        if amount is None or amount <= 0:
            await interaction.response.send_message('❌ Valor inválido. Digite um valor maior que zero.', ephemeral=True)
            return
        if get_dex_mantes_balance(interaction.user.id) < amount:
            await interaction.response.send_message('❌ Saldo insuficiente de Dex Mantes.', ephemeral=True)
            return
        with _DATA_LOCK:
            current_mantes = get_dex_mantes_balance(interaction.user.id)
            current_coins = get_balance(interaction.user.id)
            if current_mantes < amount:
                await interaction.response.send_message('❌ Saldo insuficiente de Dex Mantes.', ephemeral=True)
                return
            converted_coins = int((amount * Decimal('1000')).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
            set_dex_mantes_balance(interaction.user.id, current_mantes - amount)
            set_balance(interaction.user.id, current_coins + converted_coins)
        await interaction.response.send_message(f'✅ Conversão concluída: `{format_decimal_br(amount)} 🔷` virou `🪙 {format_integer_br(converted_coins)}`.', ephemeral=True)


class DexCoinsToMantesModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title='💱 Converter Dex Coins')
        self.amount = discord.ui.TextInput(
            label='Quantos 🪙 Dex Coins deseja converter?',
            placeholder='Ex: 5000',
            min_length=1,
            max_length=20,
            required=True,
        )
        self.add_item(self.amount)

    async def on_submit(self, interaction: discord.Interaction):
        amount = _parse_brique_coin_value(self.amount.value)
        if amount is None or amount <= 0:
            await interaction.response.send_message('❌ Valor inválido. Digite um valor maior que zero.', ephemeral=True)
            return
        if get_balance(interaction.user.id) < amount:
            await interaction.response.send_message('❌ Saldo insuficiente de Dex Coins.', ephemeral=True)
            return
        with _DATA_LOCK:
            current_coins = get_balance(interaction.user.id)
            current_mantes = get_dex_mantes_balance(interaction.user.id)
            if current_coins < amount:
                await interaction.response.send_message('❌ Saldo insuficiente de Dex Coins.', ephemeral=True)
                return
            converted_mantes = (Decimal(amount) / Decimal('1000')).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
            set_balance(interaction.user.id, current_coins - amount)
            set_dex_mantes_balance(interaction.user.id, current_mantes + converted_mantes)
        await interaction.response.send_message(f'✅ Conversão concluída: `🪙 {format_integer_br(amount)}` virou `{format_decimal_br(converted_mantes)} 🔷`.', ephemeral=True)


class ExchangeView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='🔷 → 🪙 Dex Coins', style=discord.ButtonStyle.blurple, custom_id='exchange_coins_from_mantes')
    async def dex_mantes_to_coins(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(DexMantesToCoinsModal())

    @discord.ui.button(label='🪙 → 🔷 Dex Mantes', style=discord.ButtonStyle.blurple, custom_id='exchange_mantes_from_coins')
    async def dex_coins_to_mantes(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(DexCoinsToMantesModal())

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='exchange_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_bank_embed(interaction.user.id), view=BankView(), ephemeral=True)


class BriqueUserSelect(discord.ui.UserSelect):
    def __init__(self):
        super().__init__(placeholder='👤 Selecionar Usuário', min_values=1, max_values=1, custom_id='brique_select_user')

    async def callback(self, interaction: discord.Interaction):
        if not self.values:
            await interaction.response.send_message('❌ Selecione uma pessoa para iniciar o Brique.', ephemeral=True)
            return
        target = self.values[0]
        if target.id == interaction.user.id:
            await interaction.response.send_message('❌ Você não pode negociar com você mesmo.', ephemeral=True)
            return
        offer_view = BriqueOfferView(target)
        await interaction.response.send_message(embed=build_brique_offer_embed(interaction.user, target), view=offer_view, ephemeral=True)


class BriqueUserSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.add_item(BriqueUserSelect())

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='brique_back_from_select')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_bank_embed(interaction.user.id), view=BankView(), ephemeral=True)


def build_brique_menu_embed():
    embed = discord.Embed(title='🤝 BRIQUE', description='Troque Dex Coins e/ou Dex Mantes com outro usuário.', color=0x8B5CF6)
    embed.add_field(name='Seleção', value='Escolha a pessoa com quem deseja negociar.', inline=False)
    return embed


def build_brique_offer_embed(actor: discord.User, target: discord.User):
    embed = discord.Embed(title='🤝 NOVO BRIQUE', description=f'Você está negociando com: {target.mention}', color=0x8B5CF6)
    embed.add_field(name='Você oferece', value='🪙 Dex Coins: `0`\n🔷 Dex Mantes: `0`', inline=False)
    embed.add_field(name='Você deseja receber', value='🪙 Dex Coins: `0`\n🔷 Dex Mantes: `0`', inline=False)
    return embed


class BriqueOfferModal(discord.ui.Modal):
    def __init__(self, target_user_id: int):
        super().__init__(title='🤝 Definir Oferta')
        self.target_user_id = target_user_id
        self.offer_coins = discord.ui.TextInput(
            label='Você oferece - Dex Coins',
            placeholder='Ex: 1000',
            min_length=1,
            max_length=20,
            required=True,
        )
        self.offer_mantes = discord.ui.TextInput(
            label='Você oferece - Dex Mantes',
            placeholder='Ex: 0.50',
            min_length=1,
            max_length=20,
            required=True,
        )
        self.receive_coins = discord.ui.TextInput(
            label='Você deseja receber - Dex Coins',
            placeholder='Ex: 0',
            min_length=1,
            max_length=20,
            required=True,
        )
        self.receive_mantes = discord.ui.TextInput(
            label='Você deseja receber - Dex Mantes',
            placeholder='Ex: 1.00',
            min_length=1,
            max_length=20,
            required=True,
        )
        self.add_item(self.offer_coins)
        self.add_item(self.offer_mantes)
        self.add_item(self.receive_coins)
        self.add_item(self.receive_mantes)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            offered_coins = int(self.offer_coins.value.strip()) if self.offer_coins.value.strip() else 0
            offered_mantes = _parse_brique_decimal(self.offer_mantes.value)
            wanted_coins = int(self.receive_coins.value.strip()) if self.receive_coins.value.strip() else 0
            wanted_mantes = _parse_brique_decimal(self.receive_mantes.value)
        except Exception:
            await interaction.response.send_message('❌ Valores inválidos. Use números válidos para Dex Coins e Dex Mantes.', ephemeral=True)
            return

        if offered_coins < 0 or (offered_mantes is not None and offered_mantes < 0) or wanted_coins < 0 or (wanted_mantes is not None and wanted_mantes < 0):
            await interaction.response.send_message('❌ Nenhum valor pode ser negativo.', ephemeral=True)
            return
        if offered_coins == 0 and (offered_mantes is None or offered_mantes <= 0):
            await interaction.response.send_message('❌ Você precisa oferecer ao menos uma moeda válida.', ephemeral=True)
            return
        if wanted_coins == 0 and (wanted_mantes is None or wanted_mantes <= 0):
            await interaction.response.send_message('❌ Você precisa pedir ao menos uma moeda válida.', ephemeral=True)
            return

        if offered_coins > 0 and offered_coins < 1:
            await interaction.response.send_message('❌ O mínimo de Dex Coins é 1.', ephemeral=True)
            return
        if offered_mantes is not None and offered_mantes > 0 and offered_mantes < Decimal('0.01'):
            await interaction.response.send_message('❌ O mínimo de Dex Mantes é 0,01.', ephemeral=True)
            return
        if wanted_coins > 0 and wanted_coins < 1:
            await interaction.response.send_message('❌ O mínimo de Dex Coins é 1.', ephemeral=True)
            return
        if wanted_mantes is not None and wanted_mantes > 0 and wanted_mantes < Decimal('0.01'):
            await interaction.response.send_message('❌ O mínimo de Dex Mantes é 0,01.', ephemeral=True)
            return

        if offered_coins > 0 and get_balance(interaction.user.id) < offered_coins:
            await interaction.response.send_message('❌ Saldo insuficiente. Você não possui Dex Coins suficientes para oferecer.', ephemeral=True)
            return
        if offered_mantes is not None and offered_mantes > 0 and get_dex_mantes_balance(interaction.user.id) < offered_mantes:
            await interaction.response.send_message('❌ Saldo insuficiente. Você não possui Dex Mantes suficientes para oferecer.', ephemeral=True)
            return

        offer = {
            'proposal_id': f'brique_{interaction.user.id}_{int(datetime.now(timezone.utc).timestamp() * 1000)}',
            'creator_id': interaction.user.id,
            'recipient_id': self.target_user_id,
            'offered_dex_coins': int(offered_coins),
            'offered_dex_mantes': str(offered_mantes or Decimal('0.00')),
            'wanted_dex_coins': int(wanted_coins),
            'wanted_dex_mantes': str(wanted_mantes or Decimal('0.00')),
            'status': 'PENDING',
            'created_at': datetime.now(timezone.utc).isoformat(),
        }
        BRIQUE_PROPOSALS[offer['proposal_id']] = offer
        _save_brique_proposals()
        preview = BriqueConfirmationView(offer)
        await interaction.response.send_message(embed=build_brique_confirmation_embed(interaction.user, interaction.guild.get_member(self.target_user_id) or await bot.fetch_user(self.target_user_id), offer), view=preview, ephemeral=True)


class BriqueOfferView(discord.ui.View):
    def __init__(self, target_user: discord.User):
        super().__init__(timeout=180)
        self.target_user = target_user

    @discord.ui.button(label='📝 Definir Oferta', style=discord.ButtonStyle.blurple, custom_id='brique_define_offer')
    async def definir_oferta(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(BriqueOfferModal(self.target_user.id))

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='brique_offer_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_brique_menu_embed(), view=BriqueUserSelectView(), ephemeral=True)


def build_brique_confirmation_embed(actor: discord.User, target_user: discord.User, offer: dict):
    embed = discord.Embed(title='🤝 CONFIRMAR BRIQUE', description=f'**{actor.mention} oferece:**', color=0x8B5CF6)
    embed.add_field(name='🪙 Dex Coins', value=f'`{format_integer_br(offer["offered_dex_coins"])}`', inline=False)
    embed.add_field(name='🔷 Dex Mantes', value=f'`{format_decimal_br(offer["offered_dex_mantes"])}`', inline=False)
    embed.add_field(name='Deseja receber', value=f'🪙 `{format_integer_br(offer["wanted_dex_coins"])}`\n🔷 `{format_decimal_br(offer["wanted_dex_mantes"])}`', inline=False)
    embed.add_field(name='Para', value=f'{target_user.mention}', inline=False)
    return embed


class BriqueConfirmationView(discord.ui.View):
    def __init__(self, offer: dict):
        super().__init__(timeout=180)
        self.offer = offer

    @discord.ui.button(label='📨 Enviar Proposta', style=discord.ButtonStyle.success, custom_id='brique_send_proposal')
    async def enviar(self, interaction: discord.Interaction, button: discord.ui.Button):
        offer = self.offer
        offer['status'] = 'PENDING'
        BRIQUE_PROPOSALS[offer['proposal_id']] = offer
        _save_brique_proposals()
        target_user = await bot.fetch_user(offer['recipient_id'])
        if target_user is not None:
            await target_user.send(embed=build_brique_received_embed(interaction.user, offer), view=BriqueDecisionView(offer['proposal_id']))
        await interaction.response.send_message('✅ Proposta enviada com sucesso.', ephemeral=True)

    @discord.ui.button(label='❌ Cancelar', style=discord.ButtonStyle.danger, custom_id='brique_cancel_proposal')
    async def cancelar(self, interaction: discord.Interaction, button: discord.ui.Button):
        proposal = BRIQUE_PROPOSALS.get(self.offer['proposal_id'])
        if proposal is not None:
            proposal['status'] = 'CANCELLED'
            _save_brique_proposals()
        await interaction.response.send_message('❌ Proposta cancelada.', ephemeral=True)


def build_brique_received_embed(sender: discord.User, offer: dict):
    embed = discord.Embed(title='🤝 NOVO BRIQUE', description=f'**{sender.mention}** quer fazer uma troca com você.', color=0x8B5CF6)
    embed.add_field(name='Oferece', value=f'🪙 `{format_integer_br(offer["offered_dex_coins"])}`\n🔷 `{format_decimal_br(offer["offered_dex_mantes"])}`', inline=False)
    embed.add_field(name='Deseja receber', value=f'🪙 `{format_integer_br(offer["wanted_dex_coins"])}`\n🔷 `{format_decimal_br(offer["wanted_dex_mantes"])}`', inline=False)
    return embed


class BriqueDecisionView(discord.ui.View):
    def __init__(self, proposal_id: str):
        super().__init__(timeout=180)
        self.proposal_id = proposal_id

    @discord.ui.button(label='✅ Aceitar', style=discord.ButtonStyle.success, custom_id='brique_accept')
    async def aceitar(self, interaction: discord.Interaction, button: discord.ui.Button):
        proposal = BRIQUE_PROPOSALS.get(self.proposal_id)
        if proposal is None:
            await interaction.response.send_message('❌ Esta proposta não está mais disponível.', ephemeral=True)
            return
        if proposal['status'] != 'PENDING':
            await interaction.response.send_message('❌ Esta proposta não pode mais ser aceita.', ephemeral=True)
            return
        creator = await bot.fetch_user(proposal['creator_id'])
        if creator is None:
            await interaction.response.send_message('❌ Usuário criador da proposta não foi encontrado.', ephemeral=True)
            return
        with _DATA_LOCK:
            creator_balance = get_balance(proposal['creator_id'])
            creator_mantes = get_dex_mantes_balance(proposal['creator_id'])
            recipient_balance = get_balance(proposal['recipient_id'])
            recipient_mantes = get_dex_mantes_balance(proposal['recipient_id'])
            if creator_balance < int(proposal['offered_dex_coins']) or creator_mantes < _to_decimal(proposal['offered_dex_mantes']):
                proposal['status'] = 'CANCELLED'
                _save_brique_proposals()
                await interaction.response.send_message('❌ Brique cancelado\nO usuário que criou a proposta não possui mais saldo suficiente.', ephemeral=True)
                return
            if recipient_balance < int(proposal['wanted_dex_coins']) or recipient_mantes < _to_decimal(proposal['wanted_dex_mantes']):
                proposal['status'] = 'REJECTED'
                _save_brique_proposals()
                await interaction.response.send_message('❌ Brique cancelado\nO destinatário não possui mais saldo suficiente para aceitar a proposta.', ephemeral=True)
                return

            new_creator_coins = creator_balance - int(proposal['offered_dex_coins']) + int(proposal['wanted_dex_coins'])
            new_creator_mantes = (creator_mantes - _to_decimal(proposal['offered_dex_mantes']) + _to_decimal(proposal['wanted_dex_mantes'])).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
            new_recipient_coins = recipient_balance - int(proposal['wanted_dex_coins']) + int(proposal['offered_dex_coins'])
            new_recipient_mantes = (recipient_mantes - _to_decimal(proposal['wanted_dex_mantes']) + _to_decimal(proposal['offered_dex_mantes'])).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
            set_balance(proposal['creator_id'], new_creator_coins)
            set_dex_mantes_balance(proposal['creator_id'], new_creator_mantes)
            set_balance(proposal['recipient_id'], new_recipient_coins)
            set_dex_mantes_balance(proposal['recipient_id'], new_recipient_mantes)
            proposal['status'] = 'ACCEPTED'
            _save_brique_proposals()

        await interaction.response.send_message(f'✅ Brique concluído com sucesso entre {creator.mention} e {interaction.user.mention}.', ephemeral=True)
        if creator is not None:
            try:
                await creator.send(f'✅ Brique concluído com sucesso entre {creator.mention} e {interaction.user.mention}.')
            except Exception:
                pass

    @discord.ui.button(label='❌ Recusar', style=discord.ButtonStyle.danger, custom_id='brique_reject')
    async def recusar(self, interaction: discord.Interaction, button: discord.ui.Button):
        proposal = BRIQUE_PROPOSALS.get(self.proposal_id)
        if proposal is None:
            await interaction.response.send_message('❌ Esta proposta não está mais disponível.', ephemeral=True)
            return
        if proposal['status'] != 'PENDING':
            await interaction.response.send_message('❌ Esta proposta já não está pendente.', ephemeral=True)
            return
        proposal['status'] = 'REJECTED'
        _save_brique_proposals()
        await interaction.response.send_message('❌ Proposta recusada.', ephemeral=True)


def build_bank_embed(user_id: int):
    dex_coins = get_balance(user_id)
    dex_mantes = get_dex_mantes_balance(user_id)
    embed = discord.Embed(title='🏦 Banco Dextroier', description='**Seus saldos**', color=0x8B5CF6)
    embed.add_field(name='🪙 Dex Coins', value=f'`{format_integer_br(dex_coins)}`', inline=False)
    embed.add_field(name='🔷 Dex Mantes', value=f'`{format_decimal_br(dex_mantes)}`', inline=False)
    embed.add_field(name='─────────────────', value='🔷 **Dex Mantes**\n`1 🔷 = US$ 1,00`\nDepósito mínimo: `US$ 0,50`', inline=False)
    return embed


def build_bank_deposit_embed(user_id: int):
    embed = discord.Embed(title='💳 DEPÓSITO', description='Escolha o valor que deseja depositar.', color=0x8B5CF6)
    embed.add_field(name='Mínimo', value='**US$ 0,50**', inline=False)
    embed.add_field(name='Câmbio', value='O valor será convertido de acordo com a cotação atual do dólar.', inline=False)
    embed.add_field(name='Recompensa', value='🔷 Você receberá 1 Dex Mantes para cada US$ 1,00 depositado.', inline=False)
    embed.add_field(name='Saldo atual', value=f'🔷 {format_decimal_br(get_dex_mantes_balance(user_id))} Dex Mantes', inline=False)
    return embed


class DepositValueModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title='💳 Valor do Depósito')
        self.amount_field = discord.ui.TextInput(
            label='Valor em dólares',
            placeholder='5.00',
            min_length=1,
            max_length=20,
            required=True,
        )
        self.add_item(self.amount_field)

    async def on_submit(self, interaction: discord.Interaction):
        amount_usd = parse_decimal_input(self.amount_field.value)
        if amount_usd is None or amount_usd <= Decimal('0'):
            await interaction.response.send_message('❌ Valor inválido. Use um valor em dólares maior que zero.', ephemeral=True)
            return
        if amount_usd < Decimal('0.50'):
            await interaction.response.send_message('❌ O valor mínimo permitido é **US$ 0,50**.', ephemeral=True)
            return
        try:
            rate = get_usd_to_brl_rate()
        except Exception:
            await interaction.response.send_message('❌ Não foi possível consultar a cotação do dólar neste momento.', ephemeral=True)
            return
        amount_brl = (amount_usd * rate).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        dex_amount = amount_usd.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        deposit = create_pending_deposit(interaction.user.id, amount_usd, amount_brl, rate)
        embed = discord.Embed(title='💳 CONFIRMAR DEPÓSITO', color=0x8B5CF6)
        embed.add_field(name='Valor em USD', value=f'**US$ {format_decimal_br(amount_usd)}**', inline=False)
        embed.add_field(name='Cotação utilizada', value=f'**R$ {format_decimal_br(rate)}**', inline=False)
        embed.add_field(name='Valor a pagar', value=f'**R$ {format_decimal_br(amount_brl)}**', inline=False)
        embed.add_field(name='Você receberá', value=f'**🔷 {format_decimal_br(dex_amount)} Dex Mantes**', inline=False)
        embed.add_field(name='Cotação calculada no momento da criação', value='✅' , inline=False)
        await interaction.response.send_message(embed=embed, view=DepositConfirmView(deposit['deposit_id']), ephemeral=True)


class DepositConfirmView(discord.ui.View):
    def __init__(self, deposit_id: str):
        super().__init__(timeout=180)
        self.deposit_id = deposit_id

    @discord.ui.button(label='✅ Continuar para Pagamento', style=discord.ButtonStyle.success, custom_id='deposit_continue')
    async def continuar(self, interaction: discord.Interaction, button: discord.ui.Button):
        deposit = get_deposit_by_id(self.deposit_id)
        if deposit is None:
            await interaction.response.send_message('❌ Esta cobrança já não está mais disponível.', ephemeral=True)
            return
        try:
            response = create_mercadopago_preference(deposit)
        except Exception as exc:
            await interaction.response.send_message(f'❌ Não foi possível criar a cobrança do Mercado Pago: {exc}', ephemeral=True)
            return
        link = response.get('init_point')
        if not link:
            await interaction.response.send_message('❌ Não foi possível gerar o link de pagamento.', ephemeral=True)
            return
        payment_view = discord.ui.View(timeout=300)
        payment_button = discord.ui.Button(label='💳 Pagar com Mercado Pago', style=discord.ButtonStyle.link, url=link)
        payment_view.add_item(payment_button)
        embed = discord.Embed(title='💳 PAGAMENTO CRIADO', color=0x8B5CF6)
        embed.add_field(name='Valor', value=f'**R$ {format_decimal_br(deposit["amount_brl"])}**', inline=False)
        embed.add_field(name='Você receberá', value=f'**🔷 {format_decimal_br(deposit["dex_mantes_amount"])} Dex Mantes**', inline=False)
        embed.add_field(name='Status', value='🟡 Pendente de confirmação', inline=False)
        await interaction.response.send_message(embed=embed, view=payment_view, ephemeral=True)

    @discord.ui.button(label='❌ Cancelar', style=discord.ButtonStyle.danger, custom_id='deposit_cancel')
    async def cancelar(self, interaction: discord.Interaction, button: discord.ui.Button):
        deposit = get_deposit_by_id(self.deposit_id)
        if deposit is not None:
            update_deposit_status(self.deposit_id, 'CANCELLED')
        await interaction.response.send_message('❌ Depósito cancelado.', ephemeral=True)


class DepositView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='💰 Informar Valor', style=discord.ButtonStyle.blurple, custom_id='deposit_value')
    async def informar_valor(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(DepositValueModal())

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='deposit_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_bank_embed(interaction.user.id), view=BankView(), file=discord.File(TERMS_FILE) if os.path.isfile(TERMS_FILE) else None, ephemeral=True)


class GameSelectionView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='🎰 Rolar', style=discord.ButtonStyle.blurple, custom_id='game_slot')
    async def rolar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('🎰 Escolha sua aposta:', view=BetMenuView('slot'), ephemeral=True)

    @discord.ui.button(label='🎟️ Raspadinha', style=discord.ButtonStyle.blurple, custom_id='game_scratch')
    async def raspadinha(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('🎟️ Escolha sua aposta:', view=BetMenuView('scratch'), ephemeral=True)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='game_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('⚙️ Menu de ação:', view=ActionView(), ephemeral=True)


class ActionView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='🪙 Resgatar Diário', style=discord.ButtonStyle.green, custom_id='daily_claim')
    async def resgatar_diario(self, interaction: discord.Interaction, button: discord.ui.Button):
        result = claim_daily_bonus(interaction.user.id)
        if not result['ok']:
            remaining = result['remaining']
            total_seconds = max(0, int(remaining.total_seconds()))
            hours, remainder = divmod(total_seconds, 3600)
            minutes, _ = divmod(remainder, 60)
            await interaction.response.send_message(
                f'⏳ Diário indisponível\nVocê já resgatou suas Dex Coins diárias.\nPróximo resgate em: {hours}h {minutes}min',
                ephemeral=True,
            )
            return
        await interaction.response.send_message(
            f'🎁 Diário resgatado!\n+100 Dex Coins\nSaldo atual: {result["balance"]} Dex Coins',
            ephemeral=True,
        )

    @discord.ui.button(label='💸 Transferir', style=discord.ButtonStyle.blurple, custom_id='transfer_open')
    async def transferir(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title='💸 Transferir Dex Coins',
            description='Selecione o usuário que receberá as Dex Coins.',
            color=0x8B5CF6,
        )
        await interaction.response.send_message(embed=embed, view=TransferView(), ephemeral=True)

    @discord.ui.button(label='🏦 Banco', style=discord.ButtonStyle.blurple, custom_id='bank_open')
    async def banco(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = build_bank_embed(interaction.user.id)
        await interaction.response.send_message(embed=embed, view=BankView(), file=discord.File(TERMS_FILE) if os.path.isfile(TERMS_FILE) else None, ephemeral=True)

    @discord.ui.button(label='🎰 Apostar', style=discord.ButtonStyle.blurple, custom_id='bet_open')
    async def apostar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('🎮 Escolha o jogo:', view=GameSelectionView(), ephemeral=True)

    @discord.ui.button(label='⚙️ Genérico', style=discord.ButtonStyle.blurple, custom_id='generic_open')
    async def generico(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title='⚙️ FUNÇÕES GERAIS',
            description='Ferramentas gerais do Dextroier.',
            color=0x8B5CF6,
        )
        await interaction.response.send_message(embed=embed, view=GenericMenuView(), ephemeral=True)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='action_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title='🎮 Menu Social', description='Escolha uma opção abaixo.', color=0x8B5CF6)
        await interaction.response.send_message(embed=embed, view=MenuView(), ephemeral=True)


def build_server_info_embed(guild: discord.Guild):
    if guild is None:
        return discord.Embed(title='ℹ️ INFORMAÇÕES DO SERVIDOR', description='Não foi possível obter as informações do servidor.', color=0x8B5CF6)

    owner = guild.owner or bot.get_user(guild.owner_id)
    online_count = 0
    if guild.members:
        online_count = sum(1 for member in guild.members if getattr(member, 'status', None) != discord.Status.offline)

    embed = discord.Embed(title='ℹ️ INFORMAÇÕES DO SERVIDOR', color=0x8B5CF6)
    embed.add_field(name='🏠 Servidor', value=guild.name or 'Servidor', inline=False)
    embed.add_field(name='👑 Dono', value=owner.mention if owner else 'Desconhecido', inline=False)
    embed.add_field(name='👥 Membros', value=f'{guild.member_count:,}'.replace(',', '.'), inline=False)
    embed.add_field(name='🟢 Online', value=str(online_count), inline=False)
    created_at = guild.created_at.strftime('%d/%m/%Y') if guild.created_at else 'Indisponível'
    embed.add_field(name='📅 Criado em', value=created_at, inline=False)
    embed.add_field(name='🆔 Server ID', value=f'`{guild.id}`', inline=False)
    embed.add_field(name='💬 Canais', value=str(len(guild.channels)), inline=False)
    embed.add_field(name='🎭 Cargos', value=str(len(guild.roles)), inline=False)
    categories = sum(1 for channel in guild.channels if isinstance(channel, discord.CategoryChannel))
    embed.add_field(name='📚 Categorias', value=str(categories), inline=False)

    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    return embed


class GenericMenuView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='🏓 Ping', style=discord.ButtonStyle.blurple, custom_id='generic_ping')
    async def ping(self, interaction: discord.Interaction, button: discord.ui.Button):
        latency_ms = round(bot.latency * 1000) if bot.latency is not None else 0
        embed = discord.Embed(title='🏓 Pong!', description=f'Latência: **{latency_ms}ms**', color=0x8B5CF6)
        embed.add_field(name='Discord API', value=f'**{latency_ms}ms**', inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label='📁 Arquivos', style=discord.ButtonStyle.blurple, custom_id='generic_files')
    async def arquivos(self, interaction: discord.Interaction, button: discord.ui.Button):
        view = discord.ui.View()
        view.add_item(discord.ui.Button(label='📁 Acessar Arquivos', style=discord.ButtonStyle.link, url='https://linksterr.com/r/hgvr30/'))
        await interaction.response.send_message('📁 **Arquivos**\nAcesse os arquivos aqui:\nhttps://linksterr.com/r/hgvr30/', view=view, ephemeral=True)

    @discord.ui.button(label='ℹ️ Info Server', style=discord.ButtonStyle.blurple, custom_id='server_info_open')
    async def info_server(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.guild is None:
            await interaction.response.send_message('❌ Este comando só pode ser usado em um servidor Discord.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_server_info_embed(interaction.guild), view=ServerInfoView(), ephemeral=True)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='generic_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=discord.Embed(title='⚡ Ação', description='Escolha uma opção abaixo.', color=0x8B5CF6), view=ActionView(), ephemeral=True)


class ServerInfoView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='server_info_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title='⚙️ FUNÇÕES GERAIS',
            description='Ferramentas gerais do Dextroier.',
            color=0x8B5CF6,
        )
        await interaction.response.send_message(embed=embed, view=GenericMenuView(), ephemeral=True)


class BetMenuView(discord.ui.View):
    def __init__(self, game_type: str):
        super().__init__(timeout=180)
        self.game_type = game_type

    @discord.ui.button(label='🪙 50 Dex Coins', style=discord.ButtonStyle.blurple, custom_id='bet_bet50')
    async def bet_50(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._resolve_choice(interaction, 50)

    @discord.ui.button(label='💰 100 Dex Coins', style=discord.ButtonStyle.blurple, custom_id='bet_bet100')
    async def bet_100(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._resolve_choice(interaction, 100)

    @discord.ui.button(label='📊 1% dos seus Dex Coins', style=discord.ButtonStyle.blurple, custom_id='bet_bet_percent')
    async def bet_percent(self, interaction: discord.Interaction, button: discord.ui.Button):
        valor = get_percent_value(interaction.user.id)
        if valor <= 0:
            await interaction.response.send_message('❌ Você não possui saldo suficiente para apostar 1%.', ephemeral=True)
            return
        await self._resolve_choice(interaction, valor)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='bet_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('🎮 Escolha o jogo:', view=GameSelectionView(), ephemeral=True)

    async def _resolve_choice(self, interaction: discord.Interaction, valor: int):
        saldo = get_balance(interaction.user.id)
        if valor <= 0:
            await interaction.response.send_message('❌ Valor da aposta inválido.', ephemeral=True)
            return
        if valor > saldo:
            await interaction.response.send_message('❌ Saldo insuficiente para essa aposta.', ephemeral=True)
            return

        if self.game_type == 'slot':
            await interaction.response.send_message(
                f'🎰 **APOSTA**\nValor: `{valor} Dex Coins`',
                view=BetConfirmView(valor),
                ephemeral=True,
            )
            return

        await start_scratch_game(interaction, valor)


class BetConfirmView(discord.ui.View):
    def __init__(self, valor: int):
        super().__init__(timeout=180)
        self.valor = valor

    @discord.ui.button(label='🎰 ROLAR', style=discord.ButtonStyle.success, custom_id='bet_confirm_roll')
    async def rolar(self, interaction: discord.Interaction, button: discord.ui.Button):
        saldo_atual = get_balance(interaction.user.id)
        if self.valor <= 0 or self.valor > saldo_atual:
            await interaction.response.send_message('❌ Aposta inválida ou saldo insuficiente.', ephemeral=True)
            return

        set_balance(interaction.user.id, saldo_atual - self.valor)
        symbols = roll_symbols()
        resultado = get_slot_result(symbols)

        if resultado['result'] == 'trinca':
            premio = self.valor * resultado['multiplier']
            saldo_final = get_balance(interaction.user.id) + premio
            set_balance(interaction.user.id, saldo_final)
            mensagem = f'🎉 TRINCA!\nPrêmio: `+{premio} Dex Coins`'
        elif resultado['result'] == 'dupla':
            ganho = self.valor
            saldo_final = get_balance(interaction.user.id) + ganho
            set_balance(interaction.user.id, saldo_final)
            mensagem = f'↩️ Devolução da aposta\nVocê recebeu: `+{ganho} Dex Coins`'
        else:
            mensagem = '❌ Você perdeu!'
            saldo_final = get_balance(interaction.user.id)

        embed = discord.Embed(title='🎰 RESULTADO', color=0x8B5CF6)
        embed.add_field(name='Símbolos', value=f'{symbols[0]} | {symbols[1]} | {symbols[2]}', inline=False)
        embed.add_field(name='Status', value=resultado['message'], inline=False)
        embed.add_field(name='Detalhes', value=mensagem, inline=False)
        embed.add_field(name='Saldo atual', value=f'{saldo_final} Dex Coins', inline=False)
        await interaction.response.send_message(embed=embed, view=BackToMenuView(), ephemeral=True)

    @discord.ui.button(label='❌ CANCELAR', style=discord.ButtonStyle.danger, custom_id='bet_cancel')
    async def cancelar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('❌ Aposta cancelada.', ephemeral=True)

    @discord.ui.button(label='↩️ VOLTAR', style=discord.ButtonStyle.secondary, custom_id='bet_back_to_menu')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('🎮 Escolha o jogo:', view=GameSelectionView(), ephemeral=True)


async def start_scratch_game(interaction: discord.Interaction, aposta: int):
    saldo = get_balance(interaction.user.id)
    if aposta <= 0 or aposta > saldo:
        await interaction.response.send_message('❌ Saldo insuficiente ou aposta inválida.', ephemeral=True)
        return

    if interaction.user.id in SCRATCH_SESSIONS:
        await interaction.response.send_message('❌ Você já possui uma raspadinha em andamento.', ephemeral=True)
        return

    set_balance(interaction.user.id, saldo - aposta)
    board = [random.choice(SYMBOLS) for _ in range(9)]
    session = {
        'user_id': interaction.user.id,
        'aposta': aposta,
        'result': board,
        'revealed': [False] * 9,
        'finished': False,
        'final': None,
    }
    SCRATCH_SESSIONS[interaction.user.id] = session

    embed = discord.Embed(title='🎟️ SUA RASPADINHA', color=0x8B5CF6)
    embed.add_field(name='Aposta', value=f'{aposta} Dex Coins', inline=False)
    embed.add_field(name='Status', value='Raspe todos os 9 quadrados!', inline=False)
    await interaction.response.send_message(embed=embed, view=ScratchView(session), ephemeral=True)


class ScratchView(discord.ui.View):
    def __init__(self, session):
        super().__init__(timeout=300)
        self.session = session

        for index in range(9):
            label = session['result'][index] if session['revealed'][index] else '❓'
            style = discord.ButtonStyle.success if session['revealed'][index] else discord.ButtonStyle.blurple
            button = discord.ui.Button(
                label=label,
                style=style,
                custom_id=f'scratch_{index}',
                disabled=session['revealed'][index] or session['finished'],
            )
            button.callback = self._make_callback(index)
            self.add_item(button)

    def _make_callback(self, index: int):
        async def callback(interaction: discord.Interaction):
            session = SCRATCH_SESSIONS.get(interaction.user.id)
            if not session:
                await interaction.response.send_message('❌ Esta raspadinha não existe mais.', ephemeral=True)
                return

            if interaction.user.id != session['user_id']:
                await interaction.response.send_message('❌ Esta raspadinha pertence a outro usuário.', ephemeral=True)
                return

            if session['finished']:
                await interaction.response.send_message('❌ Esta raspadinha já foi finalizada.', ephemeral=True)
                return

            if session['revealed'][index]:
                await interaction.response.send_message('❌ Esse quadrado já foi revelado.', ephemeral=True)
                return

            session['revealed'][index] = True

            if all(session['revealed']):
                session['finished'] = True
                final = calculate_scratch_result(session['result'], session['aposta'])
                session['final'] = final
                saldo_final = get_balance(interaction.user.id) + final['total_return']
                set_balance(interaction.user.id, saldo_final)
                del SCRATCH_SESSIONS[interaction.user.id]

                embed = discord.Embed(title='🎟️ RESULTADO DA RASPADINHA', color=0x8B5CF6)
                grade = '\n'.join([
                    f'{session["result"][0]} {session["result"][1]} {session["result"][2]}',
                    f'{session["result"][3]} {session["result"][4]} {session["result"][5]}',
                    f'{session["result"][6]} {session["result"][7]} {session["result"][8]}',
                ])
                embed.add_field(name='Grade', value=grade, inline=False)
                embed.add_field(name='Resultado', value=final['headline'], inline=False)
                embed.add_field(name='Aposta', value=f'{session["aposta"]} Dex Coins', inline=False)
                embed.add_field(name='Retorno', value=f'{final["total_return"]} Dex Coins', inline=False)
                embed.add_field(name='Lucro', value=f'{final["profit"]} Dex Coins', inline=False)
                embed.add_field(name='Saldo atual', value=f'{get_balance(interaction.user.id)} Dex Coins', inline=False)
                await interaction.response.edit_message(embed=embed, view=BackToMenuView())
                return

            embed = discord.Embed(title='🎟️ SUA RASPADINHA', color=0x8B5CF6)
            embed.add_field(name='Aposta', value=f'{session["aposta"]} Dex Coins', inline=False)
            embed.add_field(name='Status', value='Continue raspando...', inline=False)
            await interaction.response.edit_message(embed=embed, view=ScratchView(session))

        return callback


class MenuView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='👤 Perfil', style=discord.ButtonStyle.blurple, custom_id='menu_profile')
    async def perfil(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title='👤 Perfil',
            description='Personalize seu perfil ou veja o perfil de outro usuário.\n\nEscolha uma opção abaixo.',
            color=0x8B5CF6,
        )
        await interaction.response.send_message(embed=embed, view=ProfileView(), ephemeral=True)

    @discord.ui.button(label='⚡ Ação', style=discord.ButtonStyle.blurple, custom_id='menu_action')
    async def acao(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title='⚡ Ação',
            description='Escolha uma opção abaixo.',
            color=0x8B5CF6,
        )
        await interaction.response.send_message(embed=embed, view=ActionView(), ephemeral=True)

    @discord.ui.button(label='💎 VIP Menu', style=discord.ButtonStyle.primary, custom_id='vip_menu')
    async def vip_menu(self, interaction: discord.Interaction, button: discord.ui.Button):
        if is_vip_active(interaction.user.id):
            await interaction.response.send_message(embed=build_vip_active_embed(interaction.user.id), view=VIPActiveView(), ephemeral=True)
            return
        await interaction.response.send_message(embed=build_vip_purchase_embed(interaction.user.id), view=VIPPurchaseView(), ephemeral=True)


OWNER_USER_ID = 1205994798582857751
CONFIG_FILE = os.path.join(DATA_DIR, 'bot_config.json')
BOT_CONFIG = {}
PENDING_GLOBAL_MESSAGES = {}


def _load_bot_config():
    global BOT_CONFIG
    try:
        if os.path.isfile(CONFIG_FILE):
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
            BOT_CONFIG = data if isinstance(data, dict) else {}
    except Exception:
        BOT_CONFIG = {}


def _save_bot_config():
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        tmp = CONFIG_FILE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(BOT_CONFIG, f, ensure_ascii=False, indent=2)
        os.replace(tmp, CONFIG_FILE)
    except Exception:
        pass


_load_bot_config()


def get_guild_settings(guild_id: int):
    key = str(guild_id)
    if key not in BOT_CONFIG:
        BOT_CONFIG[key] = {'global_message_channel_id': None, 'mute_role_id': None}
        _save_bot_config()
    return BOT_CONFIG[key]


def set_guild_setting(guild_id: int, field: str, value):
    settings = get_guild_settings(guild_id)
    settings[field] = value
    _save_bot_config()
    return settings


def is_admin_user(member: discord.Member | None):
    if member is None:
        return False
    return bool(member.guild_permissions.administrator)


async def ensure_mute_role(guild: discord.Guild):
    settings = get_guild_settings(guild.id)
    mute_role_id = settings.get('mute_role_id')
    if mute_role_id:
        role = guild.get_role(int(mute_role_id))
        if role is not None:
            return role
    role_name = '🔇 Mutado'
    existing = discord.utils.get(guild.roles, name=role_name)
    if existing is None:
        existing = discord.utils.get(guild.roles, name='Muted')
    if existing is not None:
        set_guild_setting(guild.id, 'mute_role_id', str(existing.id))
        return existing
    role = await guild.create_role(name='🔇 Mutado', hoist=False, mentionable=False, reason='Cargo de mute automático do bot')
    set_guild_setting(guild.id, 'mute_role_id', str(role.id))
    return role


async def apply_mute_role_to_guild(guild: discord.Guild):
    role = await ensure_mute_role(guild)
    for channel in guild.channels:
        if isinstance(channel, discord.CategoryChannel):
            try:
                perms = channel.permissions_for(guild.me)
                if perms.manage_channels:
                    await channel.set_permissions(role, send_messages=False, speak=False, stream=False, use_voice_activation=False, add_reactions=False, create_public_threads=False, create_private_threads=False, send_messages_in_threads=False, send_tts_messages=False, manage_channels=False, view_channel=True)
            except Exception:
                pass
            continue
        if isinstance(channel, (discord.TextChannel, discord.ForumChannel, discord.Thread)):
            try:
                await channel.set_permissions(role, send_messages=False, send_messages_in_threads=False, create_public_threads=False, create_private_threads=False, add_reactions=False, manage_messages=False, view_channel=True)
            except Exception:
                pass
        elif isinstance(channel, discord.VoiceChannel):
            try:
                await channel.set_permissions(role, connect=False, speak=False, stream=False, use_video=False, use_voice_activation=False, view_channel=True)
            except Exception:
                pass


async def get_primary_global_channel(guild: discord.Guild):
    settings = get_guild_settings(guild.id)
    channel_id = settings.get('global_message_channel_id')
    if channel_id:
        channel = guild.get_channel(int(channel_id))
        if channel is not None and isinstance(channel, discord.TextChannel):
            perms = channel.permissions_for(guild.me)
            if perms.send_messages:
                return channel
    if guild.system_channel:
        if guild.system_channel.permissions_for(guild.me).send_messages:
            return guild.system_channel
    for channel in guild.text_channels:
        perms = channel.permissions_for(guild.me)
        if perms.send_messages and perms.view_channel:
            return channel
    return None


async def can_moderate_target(guild: discord.Guild, actor: discord.Member, target: discord.Member):
    if target is None or actor is None:
        return False, 'Usuário inválido.'
    if actor.id == bot.user.id or target.id == bot.user.id:
        return False, 'O bot não pode moderar a si mesmo.'
    if actor.id == target.id:
        return False, 'Você não pode moderar a si mesmo.'
    if target.id == guild.owner_id:
        return False, 'Você não pode moderar o dono do servidor.'
    if target.guild_permissions.administrator:
        return False, 'Você não pode moderar um administrador.'
    if guild.me is None:
        return False, 'O bot não está disponível neste servidor.'
    if guild.me.top_role is not None and target.top_role is not None and guild.me.top_role <= target.top_role:
        return False, 'Este usuário está acima do bot na hierarquia.'
    if actor.top_role is not None and target.top_role is not None and actor.top_role <= target.top_role:
        return False, 'Este usuário está acima de você na hierarquia.'
    return True, 'ok'


class AdminInfoView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='admin_info_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_admin_menu_embed(), view=AdminMenuView(), ephemeral=True)


class AdminActionView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='📊 Analisar Tráfego', style=discord.ButtonStyle.blurple, custom_id='admin_traffic_analysis')
    async def analisar_trafego(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return

        access = check_admin_traffic_access(interaction.user.id)
        if not access['ok']:
            await interaction.response.send_message(access['message'], ephemeral=True)
            return

        await interaction.response.send_message(embed=build_admin_traffic_intro_embed(interaction.user), view=AdminTrafficAnalysisSelectView(), ephemeral=True)

    @discord.ui.button(label='🔨 Banir', style=discord.ButtonStyle.danger, custom_id='admin_ban')
    async def banir(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return
        embed = discord.Embed(title='🔨 BANIR USUÁRIO', description='Selecione o usuário que deseja banir.', color=0x8B5CF6)
        await interaction.response.send_message(embed=embed, view=AdminBanSelectView(), ephemeral=True)

    @discord.ui.button(label='👢 Expulsar', style=discord.ButtonStyle.blurple, custom_id='admin_kick')
    async def expulsar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return
        embed = discord.Embed(title='👢 EXPULSAR USUÁRIO', description='Selecione o usuário que deseja expulsar.', color=0x8B5CF6)
        await interaction.response.send_message(embed=embed, view=AdminKickSelectView(), ephemeral=True)

    @discord.ui.button(label='🔇 Mutar', style=discord.ButtonStyle.blurple, custom_id='admin_mute')
    async def mutar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return
        embed = discord.Embed(title='🔇 MUTAR USUÁRIO', description='Selecione o usuário que deseja mutar.', color=0x8B5CF6)
        await interaction.response.send_message(embed=embed, view=AdminMuteSelectView(), ephemeral=True)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='admin_action_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_admin_menu_embed(), view=AdminMenuView(), ephemeral=True)


class AdminBanSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.add_item(AdminBanSelect())

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='admin_ban_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_admin_actions_embed(), view=AdminActionView(), ephemeral=True)


class AdminKickSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.add_item(AdminKickSelect())

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='admin_kick_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_admin_actions_embed(), view=AdminActionView(), ephemeral=True)


class AdminMuteSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.add_item(AdminMuteSelect())

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='admin_mute_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_admin_actions_embed(), view=AdminActionView(), ephemeral=True)


class AdminBanSelect(discord.ui.UserSelect):
    def __init__(self):
        super().__init__(placeholder='👤 Selecionar Usuário', min_values=1, max_values=1, custom_id='admin_select_ban')

    async def callback(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return
        selected = self.values[0]
        member = interaction.guild.get_member(selected.id)
        if member is None:
            await interaction.response.send_message('❌ Usuário não encontrado no servidor.', ephemeral=True)
            return
        allowed, reason = await can_moderate_target(interaction.guild, interaction.user, member)
        if not allowed:
            await interaction.response.send_message(f'❌ {reason}', ephemeral=True)
            return
        embed = discord.Embed(title='⚠️ CONFIRMAR BANIMENTO', description='Você realmente deseja banir este usuário?', color=0xFF4D4D)
        embed.add_field(name='Usuário', value=f'{member.mention}', inline=False)
        await interaction.response.send_message(embed=embed, view=AdminBanConfirmView(member), ephemeral=True)


class AdminKickSelect(discord.ui.UserSelect):
    def __init__(self):
        super().__init__(placeholder='👤 Selecionar Usuário', min_values=1, max_values=1, custom_id='admin_select_kick')

    async def callback(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return
        selected = self.values[0]
        member = interaction.guild.get_member(selected.id)
        if member is None:
            await interaction.response.send_message('❌ Usuário não encontrado no servidor.', ephemeral=True)
            return
        allowed, reason = await can_moderate_target(interaction.guild, interaction.user, member)
        if not allowed:
            await interaction.response.send_message(f'❌ {reason}', ephemeral=True)
            return
        embed = discord.Embed(title='⚠️ CONFIRMAR EXPULSÃO', description='Confirmar expulsão?', color=0xFFB703)
        embed.add_field(name='Usuário', value=f'{member.mention}', inline=False)
        await interaction.response.send_message(embed=embed, view=AdminKickConfirmView(member), ephemeral=True)


class AdminMuteSelect(discord.ui.UserSelect):
    def __init__(self):
        super().__init__(placeholder='👤 Selecionar Usuário', min_values=1, max_values=1, custom_id='admin_select_mute')

    async def callback(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return
        selected = self.values[0]
        member = interaction.guild.get_member(selected.id)
        if member is None:
            await interaction.response.send_message('❌ Usuário não encontrado no servidor.', ephemeral=True)
            return
        allowed, reason = await can_moderate_target(interaction.guild, interaction.user, member)
        if not allowed:
            await interaction.response.send_message(f'❌ {reason}', ephemeral=True)
            return
        embed = discord.Embed(title='🔇 CONFIRMAR MUTE', description='O usuário ficará impedido de enviar mensagens e falar nos canais enquanto estiver mutado.', color=0x8B5CF6)
        embed.add_field(name='Usuário', value=f'{member.mention}', inline=False)
        await interaction.response.send_message(embed=embed, view=AdminMuteConfirmView(member), ephemeral=True)


class AdminBanConfirmView(discord.ui.View):
    def __init__(self, member: discord.Member):
        super().__init__(timeout=180)
        self.member = member

    @discord.ui.button(label='🔨 Confirmar Banimento', style=discord.ButtonStyle.danger, custom_id='admin_confirm_ban')
    async def confirmar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return
        if self.member is None:
            await interaction.response.send_message('❌ Usuário não encontrado.', ephemeral=True)
            return
        allowed, reason = await can_moderate_target(interaction.guild, interaction.user, self.member)
        if not allowed:
            await interaction.response.send_message(f'❌ {reason}', ephemeral=True)
            return
        try:
            await interaction.guild.ban(self.member, reason='Banido via Menu Admin', delete_message_days=0)
            await interaction.response.send_message(f'✅ Usuário {self.member.mention} foi banido com sucesso.', ephemeral=True)
        except Exception as exc:
            await interaction.response.send_message(f'❌ Não foi possível banir o usuário: {exc}', ephemeral=True)

    @discord.ui.button(label='❌ Cancelar', style=discord.ButtonStyle.secondary, custom_id='admin_cancel_ban')
    async def cancelar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('❌ Banimento cancelado.', ephemeral=True)


class AdminKickConfirmView(discord.ui.View):
    def __init__(self, member: discord.Member):
        super().__init__(timeout=180)
        self.member = member

    @discord.ui.button(label='👢 Confirmar Expulsão', style=discord.ButtonStyle.blurple, custom_id='admin_confirm_kick')
    async def confirmar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return
        if self.member is None:
            await interaction.response.send_message('❌ Usuário não encontrado.', ephemeral=True)
            return
        allowed, reason = await can_moderate_target(interaction.guild, interaction.user, self.member)
        if not allowed:
            await interaction.response.send_message(f'❌ {reason}', ephemeral=True)
            return
        try:
            await interaction.guild.kick(self.member, reason='Expulso via Menu Admin')
            await interaction.response.send_message(f'✅ Usuário {self.member.mention} foi expulso com sucesso.', ephemeral=True)
        except Exception as exc:
            await interaction.response.send_message(f'❌ Não foi possível expulsar o usuário: {exc}', ephemeral=True)

    @discord.ui.button(label='❌ Cancelar', style=discord.ButtonStyle.secondary, custom_id='admin_cancel_kick')
    async def cancelar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('❌ Expulsão cancelada.', ephemeral=True)


class AdminMuteConfirmView(discord.ui.View):
    def __init__(self, member: discord.Member):
        super().__init__(timeout=180)
        self.member = member

    @discord.ui.button(label='🔇 Confirmar Mute', style=discord.ButtonStyle.blurple, custom_id='admin_confirm_mute')
    async def confirmar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return
        if self.member is None:
            await interaction.response.send_message('❌ Usuário não encontrado.', ephemeral=True)
            return
        allowed, reason = await can_moderate_target(interaction.guild, interaction.user, self.member)
        if not allowed:
            await interaction.response.send_message(f'❌ {reason}', ephemeral=True)
            return
        try:
            mute_role = await ensure_mute_role(interaction.guild)
            await self.member.add_roles(mute_role, reason='Mute via Menu Admin')
            await apply_mute_role_to_guild(interaction.guild)
            await interaction.response.send_message(f'🔇 {self.member.mention} foi mutado com sucesso.', ephemeral=True)
        except Exception as exc:
            await interaction.response.send_message(f'❌ Não foi possível mutar o usuário: {exc}', ephemeral=True)

    @discord.ui.button(label='❌ Cancelar', style=discord.ButtonStyle.secondary, custom_id='admin_cancel_mute')
    async def cancelar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message('❌ Mute cancelado.', ephemeral=True)


class AdminMenuView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='⚡ Ação', style=discord.ButtonStyle.blurple, custom_id='admin_action')
    async def acao(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_admin_actions_embed(), view=AdminActionView(), ephemeral=True)

    @discord.ui.button(label='ℹ️ Informação', style=discord.ButtonStyle.grey, custom_id='admin_info')
    async def informacao(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_admin_info_embed(), view=AdminInfoView(), ephemeral=True)


def build_admin_menu_embed():
    embed = discord.Embed(title='🛡️ PAINEL ADMINISTRATIVO', description='Gerenciamento e moderação do servidor.\n\nSelecione uma categoria abaixo.', color=0x8B5CF6)
    return embed


def build_admin_actions_embed():
    embed = discord.Embed(title='⚡ AÇÕES ADMINISTRATIVAS', description='Selecione uma ação de moderação.', color=0x8B5CF6)
    return embed


def build_admin_info_embed():
    latency = round(bot.latency * 1000)
    guild_count = len(bot.guilds)
    total_members = sum(len(guild.members) for guild in bot.guilds)
    embed = discord.Embed(title='ℹ️ INFORMAÇÃO ADMINISTRATIVA', description='Painel de status do bot.', color=0x8B5CF6)
    embed.add_field(name='🖥️ Servidores', value=str(guild_count), inline=True)
    embed.add_field(name='👥 Usuários', value=str(total_members), inline=True)
    embed.add_field(name='📡 Latência', value=f'{latency} ms', inline=True)
    embed.add_field(name='🟢 Status', value='Online', inline=True)
    embed.add_field(name='🧩 Versão', value='Dex Bot v1.0', inline=True)
    return embed


AI_PROMPT_FILE = os.path.join(os.path.dirname(__file__), 'AIpromt.txt')
GEMINI_API_FILE = os.path.join(os.path.dirname(__file__), 'GeminiAPI.txt')
OWNER_AI_SESSIONS = {}


def ensure_ai_prompt_file():
    if not os.path.isfile(AI_PROMPT_FILE):
        default_prompt = 'Você é a Dextroier AI.\nVocê responde como assistente oficial do Dextroier.\nO dono do bot é o usuário com ID 1205994798582857751.\nO nome do bot é Dextroier.\nResponda com precisão, brevidade e profissionalismo.\n'
        with open(AI_PROMPT_FILE, 'w', encoding='utf-8') as f:
            f.write(default_prompt)
    return AI_PROMPT_FILE


def load_ai_prompt():
    ensure_ai_prompt_file()
    try:
        with open(AI_PROMPT_FILE, 'r', encoding='utf-8') as f:
            text = f.read()
        return text.strip() or 'Você é a Dextroier AI.'
    except Exception:
        return 'Você é a Dextroier AI.'


def append_ai_prompt(paragraph: str):
    text = (paragraph or '').strip()
    if not text:
        raise ValueError('Parágrafo inválido.')
    current = load_ai_prompt()
    final_text = current.rstrip() + '\n\n' + text.strip() + '\n'
    with open(AI_PROMPT_FILE, 'w', encoding='utf-8') as f:
        f.write(final_text)
    return final_text


def loadGeminiApiKey():
    env_keys = [
        os.getenv('GEMINI_API_KEY'),
        os.getenv('GOOGLE_GEMINI_API_KEY'),
        os.getenv('GOOGLE_API_KEY'),
    ]
    for value in env_keys:
        if value and value.strip():
            return value.strip().strip('"\'')

    if not os.path.isfile(GEMINI_API_FILE):
        return None

    try:
        with open(GEMINI_API_FILE, 'r', encoding='utf-8') as file_handle:
            lines = [line.rstrip('\n') for line in file_handle]

        for index, line in enumerate(lines):
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.lower().startswith('api:'):
                value = stripped[4:].strip().strip('"\'')
                if value:
                    return value
                for next_line in lines[index + 1:]:
                    next_value = next_line.strip()
                    if next_value and not next_value.lower().startswith(('nome', 'name', 'número', 'numero', 'id do projeto', 'id do', 'project')):
                        return next_value.strip('"\'').strip()
                return None
        return None
    except Exception:
        return None


def get_gemini_api_key():
    return loadGeminiApiKey()


def resolve_gemini_model():
    for candidate in ['gemini-3.6-flash', 'gemini-3.5-flash', 'gemini-2.5-flash']:
        if candidate:
            return candidate
    return 'gemini-3.6-flash'


def describe_gemini_http_error(exc):
    status = getattr(exc, 'status_code', None)
    status = status if isinstance(status, int) else None
    details = getattr(exc, 'message', None) or str(exc)
    details_lower = (details or '').lower()

    if status in (400,):
        return 'Gemini HTTP 400 — requisição inválida'
    if status in (401, 403):
        return 'Gemini HTTP 401/403 — API Key inválida, expirada ou sem permissão'
    if status == 429:
        return 'Gemini HTTP 429 — limite de uso atingido'
    if status in (500, 503):
        return 'Gemini HTTP 500/503 — serviço temporariamente indisponível'
    if 'unauthorized' in details_lower or 'forbidden' in details_lower or 'api key' in details_lower:
        return 'Gemini HTTP 401/403 — API Key inválida, expirada ou sem permissão'
    if '429' in details_lower or 'rate limit' in details_lower or 'quota' in details_lower:
        return 'Gemini HTTP 429 — limite de uso atingido'
    if status is not None:
        return f'Gemini HTTP {status} — erro de consulta à API'
    if 'timeout' in details_lower:
        return 'Gemini HTTP timeout — serviço temporariamente indisponível'
    return 'Gemini HTTP — erro de consulta à API'


PROMTVIP_FILE = os.path.join(os.path.dirname(__file__), 'PROMTVIP.txt')
VIP_AI_SESSIONS = {}


def load_vip_ai_prompt():
    if not os.path.isfile(PROMTVIP_FILE):
        raise FileNotFoundError('PROMTVIP não encontrado.')
    with open(PROMTVIP_FILE, 'r', encoding='utf-8') as file_handle:
        text = file_handle.read()
    cleaned = text.strip()
    if not cleaned:
        raise ValueError('PROMTVIP vazio.')
    return cleaned


def get_vip_ai_usage(user_id: int):
    profile = get_profile(user_id)
    today = datetime.now(timezone.utc).date().isoformat()
    usage_date = profile.get('vip_ai_usage_date')
    usage = int(profile.get('vip_ai_usage') or 0)
    if usage_date != today:
        profile['vip_ai_usage_date'] = today
        profile['vip_ai_usage'] = 0
        usage = 0
        _save_profiles()
    return usage, today


def consume_vip_ai_usage(user_id: int):
    with _DATA_LOCK:
        profile = get_profile(user_id)
        today = datetime.now(timezone.utc).date().isoformat()
        usage_date = profile.get('vip_ai_usage_date')
        if usage_date != today:
            profile['vip_ai_usage_date'] = today
            profile['vip_ai_usage'] = 0
        usage = int(profile.get('vip_ai_usage') or 0)
        if usage >= 5:
            return {'ok': False, 'used': usage, 'remaining': 0}
        profile['vip_ai_usage'] = usage + 1
        _save_profiles()
        return {'ok': True, 'used': usage + 1, 'remaining': max(0, 5 - (usage + 1))}


def get_vip_ai_chat(user_id: int):
    if not is_vip_active(user_id):
        raise RuntimeError('❌ Seu VIP expirou. Renove o VIP para continuar utilizando a AI.')

    try:
        system_instruction = load_vip_ai_prompt()
    except Exception as exc:
        raise RuntimeError('❌ A configuração da AI VIP não está disponível no momento.') from exc

    if genai is None:
        raise RuntimeError('❌ A API do Gemini não está configurada corretamente.')

    api_key = loadGeminiApiKey()
    if not api_key:
        raise RuntimeError('❌ API Key do Gemini não encontrada em GeminiAPI.txt')

    session = VIP_AI_SESSIONS.get(user_id)
    if session is not None and session.get('system_instruction') == system_instruction:
        return session['chat']

    client = genai.Client(api_key=api_key)
    chat = client.chats.create(
        model=resolve_gemini_model(),
        config={'system_instruction': system_instruction},
    )
    VIP_AI_SESSIONS[user_id] = {'chat': chat, 'system_instruction': system_instruction}
    return chat


def build_vip_ai_embed(user_id: int):
    usage, _ = get_vip_ai_usage(user_id)
    remaining = max(0, 5 - usage)
    embed = discord.Embed(title='🤖 Dextroier AI — VIP', description='Converse com a inteligência artificial exclusiva para usuários VIP.', color=0x8B5CF6)
    embed.add_field(name='📊 Usos restantes hoje', value=f'`{remaining}/5`', inline=False)
    return embed


def build_vip_ai_menu_embed(user_id: int):
    usage, _ = get_vip_ai_usage(user_id)
    remaining = max(0, 5 - usage)
    embed = discord.Embed(title='🤖 Dextroier AI — VIP', description='🟢 VIP ativo\n\n📊 **Usos hoje:** `{remaining}/5`\n\nEscolha uma opção:', color=0x8B5CF6)
    return embed


def build_ai_context(user_message: str, history=None):
    history = history or []
    instructions = load_ai_prompt()
    lines = [instructions]
    if history:
        lines.append('')
        lines.append('=== HISTÓRICO DA CONVERSAÇÃO ===')
        for entry in history:
            role = entry.get('role', 'user')
            text = (entry.get('text') or '').strip()
            if not text:
                continue
            prefix = 'Dono' if role == 'user' else 'IA'
            lines.append(f'{prefix}: {text}')
    lines.append('')
    lines.append('=== MENSAGEM ATUAL DO DONO ===')
    lines.append(user_message.strip())
    return '\n'.join(lines)


def get_owner_ai_chat(user_id: int):
    api_key = loadGeminiApiKey()
    if not api_key:
        raise RuntimeError('❌ API Key do Gemini não encontrada em GeminiAPI.txt')
    if genai is None:
        raise RuntimeError('❌ A API do Gemini não está configurada corretamente.')

    current_prompt = load_ai_prompt()
    prompt_hash = hashlib.sha256(current_prompt.encode('utf-8')).hexdigest()
    session = OWNER_AI_SESSIONS.get(user_id)

    if session is None or session.get('prompt_hash') != prompt_hash:
        print(f'[AI] criando nova sessão Gemini para user_id={user_id}')
        client = genai.Client(api_key=api_key)
        chat = client.chats.create(
            model=resolve_gemini_model(),
            config={'system_instruction': current_prompt},
        )
        OWNER_AI_SESSIONS[user_id] = {'chat': chat, 'client': client, 'prompt_hash': prompt_hash}
        return chat

    print(f'[AI] reutilizando sessão Gemini para user_id={user_id}')
    return session['chat']


TRAFFIC_ANALYSIS_PROMPT = '''
Você é a IA de análise de tráfego do Dextroier.
Analise somente as mensagens do canal fornecido.
Não invente informações que não estejam presentes no histórico enviado.
Seja objetiva, profissional e baseada em padrões reais da conversa.
Não exponha mensagens privadas nem liste o histórico bruto no resultado final.
Não tome ações automáticas como banir, mutar, expulsar ou apagar mensagens.

Sua resposta deve ser um resumo útil para um administrador, em português, em um formato com estas seções:

### 📈 Interação
Descreva o nível de participação, frequência e se o canal parece ativo, com conversas em andamento ou pouco movimento.

### 💡 Oportunidades
Liste oportunidades práticas para aumentar a participação, com sugestões específicas baseadas nas mensagens analisadas.

### ⚠️ Pontos de atenção
Identifique problemas reais de comunicação, concentração de conversa em poucos usuários, ausência de respostas, ou tópicos que não geram engajamento.

### 🎯 Recomendações
Dê um conjunto de ações concretas e acionáveis para melhorar a interação do canal.

Resuma tudo em um texto profissional, curto e direto, sem frases genéricas.
'''


def get_admin_traffic_limit(user_id: int):
    if is_vip_active(user_id):
        return {'plan': '💎 VIP', 'max_messages': 25, 'limit_type': 'day', 'limit_label': '1 por dia'}
    return {'plan': 'Normal', 'max_messages': 10, 'limit_type': 'month', 'limit_label': '1 por mês'}


def get_admin_traffic_usage(user_id: int):
    profile = get_profile(user_id)
    if is_vip_active(user_id):
        today = datetime.now(timezone.utc).date().isoformat()
        if profile.get('traffic_analysis_date') != today:
            profile['traffic_analysis_date'] = today
            profile['traffic_analysis_count'] = 0
            _save_profiles()
        return int(profile.get('traffic_analysis_count') or 0), today, 'day'
    month_key = datetime.now(timezone.utc).strftime('%Y-%m')
    if profile.get('traffic_analysis_month') != month_key:
        profile['traffic_analysis_month'] = month_key
        profile['traffic_analysis_count'] = 0
        _save_profiles()
    return int(profile.get('traffic_analysis_count') or 0), month_key, 'month'


def consume_admin_traffic_usage(user_id: int):
    with _DATA_LOCK:
        profile = get_profile(user_id)
        if is_vip_active(user_id):
            today = datetime.now(timezone.utc).date().isoformat()
            if profile.get('traffic_analysis_date') != today:
                profile['traffic_analysis_date'] = today
                profile['traffic_analysis_count'] = 0
            usage = int(profile.get('traffic_analysis_count') or 0)
            if usage >= 1:
                return {'ok': False, 'used': usage, 'remaining': 0, 'limit_type': 'day'}
            profile['traffic_analysis_count'] = 1
            profile['traffic_analysis_date'] = today
            _save_profiles()
            return {'ok': True, 'used': 1, 'remaining': 0, 'limit_type': 'day'}

        month_key = datetime.now(timezone.utc).strftime('%Y-%m')
        if profile.get('traffic_analysis_month') != month_key:
            profile['traffic_analysis_month'] = month_key
            profile['traffic_analysis_count'] = 0
        usage = int(profile.get('traffic_analysis_count') or 0)
        if usage >= 1:
            return {'ok': False, 'used': usage, 'remaining': 0, 'limit_type': 'month'}
        profile['traffic_analysis_count'] = 1
        profile['traffic_analysis_month'] = month_key
        _save_profiles()
        return {'ok': True, 'used': 1, 'remaining': 0, 'limit_type': 'month'}


def rollback_admin_traffic_usage(user_id: int):
    with _DATA_LOCK:
        profile = get_profile(user_id)
        current = int(profile.get('traffic_analysis_count') or 0)
        if current > 0:
            profile['traffic_analysis_count'] = max(0, current - 1)
            _save_profiles()


def check_admin_traffic_access(user_id: int):
    if not is_vip_active(user_id):
        usage, _, limit_type = get_admin_traffic_usage(user_id)
        if usage >= 1:
            return {'ok': False, 'message': '⏳ **Limite mensal atingido**\n\nVocê já utilizou sua análise de tráfego deste mês.\n\n💎 Com VIP, você pode utilizar a análise uma vez por dia e analisar 25 mensagens.', 'limit_type': 'month'}
        return {'ok': True, 'plan': 'Normal', 'messages': 10, 'limit_type': 'month', 'limit_label': '1 por mês'}

    usage, _, _ = get_admin_traffic_usage(user_id)
    if usage >= 1:
        return {'ok': False, 'message': '⏳ **Limite diário atingido**\n\nVocê já utilizou sua análise de tráfego hoje.\n\nTente novamente amanhã.', 'limit_type': 'day'}
    return {'ok': True, 'plan': '💎 VIP', 'messages': 25, 'limit_type': 'day', 'limit_label': '1 por dia'}


async def fetch_channel_traffic_messages(channel: discord.TextChannel, limit: int):
    messages = []
    async for message in channel.history(limit=limit, oldest_first=False):
        if message.author.bot:
            continue
        content = (message.content or '').strip()
        if not content:
            continue
        author_name = getattr(message.author, 'display_name', None) or getattr(message.author, 'name', None) or 'Usuário'
        messages.append(f'{author_name}: {content}')
    return messages[:limit]


def format_traffic_analysis_response(text: str):
    sections = {
        'interacao': '📈 Interação',
        'oportunidades': '💡 Oportunidades',
        'atencao': '⚠️ Pontos de atenção',
        'recomendacoes': '🎯 Recomendações',
    }
    normalized = (text or '').strip()
    if not normalized:
        return '### 📈 Interação\nNão foi possível extrair uma análise objetiva do canal.\n\n### 💡 Oportunidades\nAjuste o canal ou tente novamente com um histórico mais ativo.\n\n### ⚠️ Pontos de atenção\nNão houve dados suficientes para identificar padrões claros.\n\n### 🎯 Recomendações\nTente reunir mais interações antes de realizar uma nova análise.'
    return normalized


def analyze_traffic_with_gemini(channel_name: str, messages: list, user_plan: str, max_messages: int):
    if not messages:
        raise ValueError('Não há mensagens suficientes para analisar neste canal.')
    if genai is None:
        raise RuntimeError('❌ A API do Gemini não está configurada corretamente.')
    api_key = loadGeminiApiKey()
    if not api_key:
        raise RuntimeError('❌ API Key do Gemini não encontrada em GeminiAPI.txt')

    payload = '\n'.join(f'{idx + 1}. {entry}' for idx, entry in enumerate(messages[:max_messages]))
    prompt = (
        f'{TRAFFIC_ANALYSIS_PROMPT}\n\n'
        f'Canal analisado: #{channel_name}\n'
        f'Plano do administrador: {user_plan}\n'
        f'Mensagens analisadas: {len(messages)}\n\n'
        'Histórico analisado:\n'
        f'{payload}\n\n'
        'Produza uma análise em português, organizada em quatro seções: Interação, Oportunidades, Pontos de atenção e Recomendações.'
    )

    client = genai.Client(api_key=api_key)
    chat = client.chats.create(
        model=resolve_gemini_model(),
        config={'system_instruction': TRAFFIC_ANALYSIS_PROMPT},
    )
    response = chat.send_message(prompt)
    text = getattr(response, 'text', None)
    if isinstance(text, str) and text.strip():
        return format_traffic_analysis_response(text)

    if hasattr(response, 'candidates'):
        for candidate in response.candidates or []:
            content = getattr(candidate, 'content', None)
            parts = getattr(content, 'parts', None) or []
            texts = []
            for part in parts:
                if getattr(part, 'text', None):
                    texts.append(str(part.text))
            assembled = ''.join(texts).strip()
            if assembled:
                return format_traffic_analysis_response(assembled)
    raise RuntimeError('❌ A API do Gemini respondeu vazia.')


def build_admin_traffic_intro_embed(user: discord.User):
    access = check_admin_traffic_access(user.id)
    if not access['ok']:
        embed = discord.Embed(title='📊 ANALISAR TRÁFEGO', description='Limite alcançado.', color=0x8B5CF6)
        embed.add_field(name='Status', value=access['message'], inline=False)
        return embed
    embed = discord.Embed(title='📊 ANALISAR TRÁFEGO', description='Selecione o canal de texto que deseja analisar.', color=0x8B5CF6)
    embed.add_field(name='Admin', value=user.mention, inline=False)
    embed.add_field(name='Plano', value=access['plan'], inline=False)
    embed.add_field(name='Mensagens analisadas', value=str(access['messages']), inline=False)
    embed.add_field(name='Limite', value=access['limit_label'], inline=False)
    return embed


def build_admin_traffic_report_embed(channel: discord.TextChannel, plan: str, analyzed_count: int, analysis_text: str):
    embed = discord.Embed(title='📊 Análise de Tráfego', description='Relatório gerado com base nas mensagens recentes do canal.', color=0x8B5CF6)
    embed.add_field(name='Canal', value=f'#{channel.name}', inline=False)
    embed.add_field(name='Mensagens analisadas', value=str(analyzed_count), inline=False)
    embed.add_field(name='Plano', value=plan, inline=False)
    embed.add_field(name='📈 Interação', value=analysis_text.split('### 📈 Interação', 1)[-1].split('###', 1)[0].strip()[:1024] if '### 📈 Interação' in analysis_text else analysis_text[:1024], inline=False)
    embed.add_field(name='💡 Oportunidades', value=(analysis_text.split('### 💡 Oportunidades', 1)[-1].split('###', 1)[0].strip() if '### 💡 Oportunidades' in analysis_text else 'Sem recomendação específica.')[:1024], inline=False)
    embed.add_field(name='⚠️ Pontos de atenção', value=(analysis_text.split('### ⚠️ Pontos de atenção', 1)[-1].split('###', 1)[0].strip() if '### ⚠️ Pontos de atenção' in analysis_text else 'Sem pontos de atenção claros.')[:1024], inline=False)
    embed.add_field(name='🎯 Recomendações', value=(analysis_text.split('### 🎯 Recomendações', 1)[-1].strip() if '### 🎯 Recomendações' in analysis_text else 'Sem recomendações específicas.')[:1024], inline=False)
    return embed


class AdminTrafficAnalysisChannelSelect(discord.ui.ChannelSelect):
    def __init__(self):
        super().__init__(placeholder='📍 Selecionar canal', min_values=1, max_values=1, custom_id='admin_traffic_channel_select', channel_types=[discord.ChannelType.text])

    async def callback(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
            return

        access = check_admin_traffic_access(interaction.user.id)
        if not access['ok']:
            await interaction.response.send_message(access['message'], ephemeral=True)
            return

        channel = self.values[0]
        if not isinstance(channel, discord.TextChannel):
            await interaction.response.send_message('❌ Canal inválido para análise.', ephemeral=True)
            return
        perms = channel.permissions_for(interaction.guild.me)
        if not perms.view_channel or not perms.read_message_history:
            await interaction.response.send_message('❌ Não consigo acessar o histórico desse canal.', ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)
        result = consume_admin_traffic_usage(interaction.user.id)
        if not result['ok']:
            await interaction.followup.send('⏳ **Limite atingido**\n\nSua análise já foi utilizada neste período.', ephemeral=True)
            return

        try:
            limit = access['messages']
            print(f'[AI-TRAFFIC] Iniciando análise para user_id={interaction.user.id} canal={channel.id} limite={limit}')
            messages = await fetch_channel_traffic_messages(channel, limit)
            if not messages:
                rollback_admin_traffic_usage(interaction.user.id)
                await interaction.followup.send('❌ Não há mensagens recentes suficientes neste canal para gerar uma análise útil.', ephemeral=True)
                return

            analysis_text = analyze_traffic_with_gemini(channel.name, messages, access['plan'], limit)
            embed = build_admin_traffic_report_embed(channel, access['plan'], len(messages), analysis_text)
            await interaction.followup.send(embed=embed, ephemeral=True)
            print(f'[AI-TRAFFIC] Análise concluída para user_id={interaction.user.id} em #{channel.name}')
        except asyncio.TimeoutError:
            rollback_admin_traffic_usage(interaction.user.id)
            print('[AI-TRAFFIC] ERRO: timeout ao consultar Gemini')
            await interaction.followup.send('⏱️ **O Gemini demorou demais para responder.**\n\nTente novamente mais tarde.', ephemeral=True)
        except Exception as exc:
            rollback_admin_traffic_usage(interaction.user.id)
            print(f'[AI-TRAFFIC] ERRO Gemini: {type(exc).__name__}: {exc}')
            await interaction.followup.send('❌ **Erro ao analisar o tráfego do canal**\n\nNão foi possível concluir a análise do histórico solicitado.', ephemeral=True)


class AdminTrafficAnalysisSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.add_item(AdminTrafficAnalysisChannelSelect())

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='admin_traffic_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(embed=build_admin_actions_embed(), view=AdminActionView(), ephemeral=True)


def build_admin_traffic_analysis_button(user: discord.User):
    access = check_admin_traffic_access(user.id)
    if not access['ok']:
        return discord.ui.Button(label='📊 Analisar Tráfego', style=discord.ButtonStyle.gray, custom_id='admin_traffic_analysis', disabled=True)
    return discord.ui.Button(label='📊 Analisar Tráfego', style=discord.ButtonStyle.blurple, custom_id='admin_traffic_analysis')


def generate_ai_response(user_message: str, history=None):
    history = history or []
    api_key = loadGeminiApiKey()
    if not api_key:
        raise RuntimeError('❌ API Key do Gemini não encontrada em GeminiAPI.txt')

    if genai is None:
        raise RuntimeError('❌ A API do Gemini não está configurada corretamente.')

    prompt = build_ai_context(user_message, history)
    model_name = resolve_gemini_model()

    try:
        print('[AI] Enviando mensagem para Gemini')
        client = genai.Client(api_key=api_key)
        chat = client.chats.create(
            model=model_name,
            config={'system_instruction': load_ai_prompt()},
        )
        response = chat.send_message(prompt)
    except Exception as exc:
        print(f'[AI] ERRO Gemini: {type(exc).__name__}: {exc}')
        raise RuntimeError(describe_gemini_http_error(exc)) from exc

    try:
        text = getattr(response, 'text', None)
        if isinstance(text, str) and text.strip():
            print('[AI] Resposta recebida do Gemini')
            return text.strip()

        if hasattr(response, 'candidates'):
            for candidate in response.candidates or []:
                content = getattr(candidate, 'content', None)
                parts = getattr(content, 'parts', None) or []
                texts = []
                for part in parts:
                    part_text = getattr(part, 'text', None)
                    if part_text:
                        texts.append(str(part_text))
                assembled = ''.join(texts).strip()
                if assembled:
                    print('[AI] Resposta recebida do Gemini')
                    return assembled

        print('[AI] ERRO Gemini: resposta vazia')
        raise RuntimeError('❌ A API do Gemini respondeu vazia.')
    except RuntimeError:
        raise
    except Exception as exc:
        print(f'[AI] ERRO Gemini: resposta inválida: {exc}')
        raise RuntimeError('❌ Não foi possível interpretar a resposta do Gemini.') from exc


def split_discord_message(text: str, chunk_size: int = 1800):
    text = text or ''
    if len(text) <= chunk_size:
        return [text]
    chunks = []
    current = ''
    for paragraph in text.split('\n'):
        if len(current) + len(paragraph) + 1 <= chunk_size:
            current = (current + '\n' + paragraph).strip('\n') if current else paragraph
        else:
            if current:
                chunks.append(current)
            current = paragraph
    if current:
        chunks.append(current)
    if len(chunks) == 1 and len(chunks[0]) > chunk_size:
        chunks = []
        for idx in range(0, len(text), chunk_size):
            chunks.append(text[idx:idx + chunk_size])
    return chunks if chunks else [text[:chunk_size]]


class VIPAIChatModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title='🤖 Dextroier AI — VIP')
        self.message = discord.ui.TextInput(
            label='Mensagem',
            placeholder='Digite sua mensagem para conversar com a IA VIP.',
            style=discord.TextStyle.long,
            min_length=1,
            max_length=2000,
            required=True,
        )
        self.add_item(self.message)

    async def on_submit(self, interaction: discord.Interaction):
        if not is_vip_active(interaction.user.id):
            await interaction.response.send_message('❌ **Seu VIP expirou.**\n\nRenove o VIP para continuar utilizando a AI.', ephemeral=True)
            return

        usage, _ = get_vip_ai_usage(interaction.user.id)
        if usage >= 5:
            await interaction.response.send_message('⏳ **Limite diário atingido**\n\nVocê utilizou suas 5 mensagens de AI de hoje.\n\nO limite será renovado no próximo período diário.', ephemeral=True)
            return

        user_text = self.message.value.strip()
        if not user_text:
            await interaction.response.send_message('❌ Sua mensagem não pode estar vazia.', ephemeral=True)
            return

        print(f'[AI-VIP] Interaction recebida para user_id={interaction.user.id}')
        await interaction.response.defer(ephemeral=True)

        try:
            chat = await asyncio.to_thread(get_vip_ai_chat, interaction.user.id)
            print(f'[AI-VIP] Sessão Gemini criada/recuperada para user_id={interaction.user.id}')
            response = await asyncio.to_thread(chat.send_message, user_text)
            answer = getattr(response, 'text', None)
            if not isinstance(answer, str) or not answer.strip():
                for candidate in getattr(response, 'candidates', None) or []:
                    content = getattr(candidate, 'content', None)
                    parts = getattr(content, 'parts', None) or []
                    texts = []
                    for part in parts:
                        part_text = getattr(part, 'text', None)
                        if part_text:
                            texts.append(str(part_text))
                    answer = ''.join(texts).strip()
                    if answer:
                        break
            if not answer or not answer.strip():
                raise RuntimeError('❌ A API do Gemini respondeu vazia.')

            result = consume_vip_ai_usage(interaction.user.id)
            if not result['ok']:
                await interaction.followup.send('⏳ **Limite diário atingido**\n\nVocê utilizou suas 5 mensagens de AI de hoje.\n\nO limite será renovado no próximo período diário.', ephemeral=True)
                return

            print(f'[AI-VIP] Resposta recebida e uso consumido: {result["used"]}/5')
            for chunk in split_discord_message(answer):
                await interaction.followup.send(chunk, ephemeral=True)
        except asyncio.TimeoutError:
            print('[AI-VIP] ERRO Gemini: timeout')
            await interaction.followup.send('⏱️ **O Gemini demorou demais para responder.**\n\nTente enviar a mensagem novamente.', ephemeral=True)
        except Exception as exc:
            print(f'[AI-VIP] ERRO Gemini: {type(exc).__name__}: {exc}')
            await interaction.followup.send('❌ **Erro ao consultar a Dextroier AI**\n\nNão foi possível obter uma resposta do Gemini.\n\nTente novamente.', ephemeral=True)


class VIPAIChatView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='💬 Enviar Mensagem', style=discord.ButtonStyle.blurple, custom_id='vip_ai_send')
    async def enviar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_vip_active(interaction.user.id):
            await interaction.response.send_message('❌ **Seu VIP expirou.**\n\nRenove o VIP para continuar utilizando a AI.', ephemeral=True)
            return
        usage, _ = get_vip_ai_usage(interaction.user.id)
        if usage >= 5:
            await interaction.response.send_message('⏳ **Limite diário atingido**\n\nVocê utilizou suas 5 mensagens de AI de hoje.\n\nO limite será renovado no próximo período diário.', ephemeral=True)
            return
        await interaction.response.send_modal(VIPAIChatModal())

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='vip_ai_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_vip_active(interaction.user.id):
            await interaction.response.send_message('❌ **Seu VIP expirou.**\n\nRenove o VIP para continuar utilizando a AI.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_vip_ai_menu_embed(interaction.user.id), view=VIPAIMenuView(), ephemeral=True)


class VIPAIMenuView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='💬 ChatAI', style=discord.ButtonStyle.blurple, custom_id='vip_ai_chat')
    async def chat_ai(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_vip_active(interaction.user.id):
            await interaction.response.send_message('❌ **Seu VIP expirou.**\n\nRenove o VIP para continuar utilizando a AI.', ephemeral=True)
            return
        usage, _ = get_vip_ai_usage(interaction.user.id)
        if usage >= 5:
            await interaction.response.send_message('⏳ **Limite diário atingido**\n\nVocê utilizou suas 5 mensagens de AI de hoje.\n\nO limite será renovado no próximo período diário.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_vip_ai_menu_embed(interaction.user.id), view=VIPAIChatView(), ephemeral=True)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='vip_ai_back_menu')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_vip_active(interaction.user.id):
            await interaction.response.send_message('❌ **Seu VIP expirou.**\n\nRenove o VIP para continuar utilizando a AI.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_vip_active_embed(interaction.user.id), view=VIPActiveView(), ephemeral=True)


class OwnerAIChatModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title='🤖 Dextroier AI')
        self.message = discord.ui.TextInput(
            label='Mensagem',
            placeholder='Digite sua mensagem para conversar com a IA.',
            style=discord.TextStyle.long,
            min_length=1,
            max_length=2000,
            required=True,
        )
        self.add_item(self.message)

    async def on_submit(self, interaction: discord.Interaction):
        print('[AI] Interaction recebida')
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return

        user_text = self.message.value.strip()
        if not user_text:
            await interaction.response.send_message('❌ Sua mensagem não pode estar vazia.', ephemeral=True)
            return

        print(f'[AI] Mensagem recebida: {user_text[:120]}')
        await interaction.response.defer(ephemeral=True)

        try:
            print('[AI] AIpromt.txt carregado')
            chat = await asyncio.to_thread(get_owner_ai_chat, interaction.user.id)
            print('[AI] Sessão Gemini encontrada/criada')
            print('[AI] Enviando mensagem para Gemini')
            response = await asyncio.to_thread(chat.send_message, user_text)
            answer = getattr(response, 'text', None)
            if not isinstance(answer, str) or not answer.strip():
                for candidate in getattr(response, 'candidates', None) or []:
                    content = getattr(candidate, 'content', None)
                    parts = getattr(content, 'parts', None) or []
                    texts = []
                    for part in parts:
                        part_text = getattr(part, 'text', None)
                        if part_text:
                            texts.append(str(part_text))
                    answer = ''.join(texts).strip()
                    if answer:
                        break
            if not answer or not answer.strip():
                raise RuntimeError('❌ A API do Gemini respondeu vazia.')

            print('[AI] Resposta recebida')
            session = OWNER_AI_SESSIONS.get(interaction.user.id)
            if session is None:
                session = {'chat': chat, 'client': None, 'prompt_hash': hashlib.sha256(load_ai_prompt().encode('utf-8')).hexdigest()}
                OWNER_AI_SESSIONS[interaction.user.id] = session
            history_list = session.get('history', [])
            history_list.append({'role': 'user', 'text': user_text})
            history_list.append({'role': 'model', 'text': answer})
            session['history'] = history_list[-20:]

            chunks = split_discord_message(answer)
            for index, chunk in enumerate(chunks):
                if index == 0:
                    await interaction.followup.send(chunk, ephemeral=True)
                else:
                    await interaction.followup.send(chunk, ephemeral=True)
            print('[AI] Concluído')
        except asyncio.TimeoutError:
            print('[AI] ERRO Gemini: timeout')
            await interaction.followup.send('⏱️ **O Gemini demorou demais para responder.**\n\nTente enviar a mensagem novamente.', ephemeral=True)
        except Exception as exc:
            print(f'[AI] ERRO Gemini: {type(exc).__name__}: {exc}')
            message = str(exc)
            if not message or message.startswith('❌') is False:
                message = '❌ **Erro ao consultar a Dextroier AI**\n\nNão foi possível obter uma resposta do Gemini.\n\nTente novamente.'
            await interaction.followup.send(message, ephemeral=True)


class OwnerAIChatView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='💬 Enviar Mensagem', style=discord.ButtonStyle.blurple, custom_id='owner_ai_send')
    async def enviar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        await interaction.response.send_modal(OwnerAIChatModal())

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='owner_ai_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_owner_ai_panel_embed(), view=OwnerAIMenuView(), ephemeral=True)


class OwnerAIMenuView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='💬 ChatAI', style=discord.ButtonStyle.blurple, custom_id='owner_ai_chat')
    async def chat_ai(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        await interaction.response.send_message('## 🤖 Dextroier AI\nChat iniciado.\nDigite sua mensagem para conversar com a IA.', view=OwnerAIChatView(), ephemeral=True)

    @discord.ui.button(label='➕ +Prompt', style=discord.ButtonStyle.green, custom_id='owner_ai_add_prompt')
    async def adicionar_prompt(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        await interaction.response.send_modal(AddAIPromptModal())

    @discord.ui.button(label='📥 Baixar e substituir arquivo', style=discord.ButtonStyle.grey, custom_id='owner_ai_download_replace')
    async def baixar_e_substituir(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        ensure_ai_prompt_file()
        await interaction.response.send_message(
            '## 📄 AIpromt.txt\nEste é o arquivo atual de instruções da Dextroier AI.\nEdite o arquivo localmente e envie a nova versão para substituir o arquivo atual.',
            file=discord.File(AI_PROMPT_FILE),
            ephemeral=True,
        )

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='owner_ai_back_menu')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_owner_menu_embed(), view=OwnerMenuView(), ephemeral=True)


class AddAIPromptModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title='Adicionar Prompt')
        self.paragraph = discord.ui.TextInput(
            label='Novo parágrafo',
            placeholder='O dono prefere respostas diretas e objetivas.',
            style=discord.TextStyle.long,
            min_length=1,
            max_length=2000,
            required=True,
        )
        self.add_item(self.paragraph)

    async def on_submit(self, interaction: discord.Interaction):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        try:
            append_ai_prompt(self.paragraph.value)
        except Exception as exc:
            await interaction.response.send_message(f'❌ Não foi possível atualizar o AIpromt.txt: {exc}', ephemeral=True)
            return
        await interaction.response.send_message('## ✅ Prompt adicionado\nO novo parágrafo foi adicionado ao `AIpromt.txt`.', ephemeral=True)


def build_owner_ai_panel_embed():
    embed = discord.Embed(title='🤖 Dextroier AI', description='Sistema de inteligência artificial do Dextroier.\n\nEscolha uma opção.', color=0x8B5CF6)
    return embed


class OwnerInfoView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='owner_info_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_owner_menu_embed(), view=OwnerMenuView(), ephemeral=True)


class OwnerActionView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='🌎 Mensagem Global', style=discord.ButtonStyle.blurple, custom_id='owner_global_message')
    async def mensagem_global(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        await interaction.response.send_modal(GlobalMessageModal())

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='owner_action_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_owner_menu_embed(), view=OwnerMenuView(), ephemeral=True)


class OwnerMenuView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='⚡ Ação', style=discord.ButtonStyle.blurple, custom_id='owner_action')
    async def acao(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_owner_actions_embed(), view=OwnerActionView(), ephemeral=True)

    @discord.ui.button(label='ℹ️ Informação', style=discord.ButtonStyle.grey, custom_id='owner_info')
    async def informacao(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_owner_info_embed(), view=OwnerInfoView(), ephemeral=True)

    @discord.ui.button(label='🤖 Usar AI', style=discord.ButtonStyle.blurple, custom_id='owner_ai')
    async def usar_ai(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        await interaction.response.send_message(embed=build_owner_ai_panel_embed(), view=OwnerAIMenuView(), ephemeral=True)

    @discord.ui.button(label='↩️ Voltar', style=discord.ButtonStyle.secondary, custom_id='owner_back')
    async def voltar(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title='🎮 Dextroier', description='Escolha uma opção abaixo.', color=0x8B5CF6)
        await interaction.response.send_message(embed=embed, view=MenuView(), ephemeral=True)


def build_owner_menu_embed():
    embed = discord.Embed(title='👑 PAINEL DO DONO', description='Controle global do Dextroier.', color=0xF59E0B)
    return embed


def build_owner_actions_embed():
    embed = discord.Embed(title='👑 AÇÕES DO DONO', description='Funções exclusivas do proprietário do bot.', color=0xF59E0B)
    return embed


def build_owner_info_embed():
    latency = round(bot.latency * 1000)
    guild_count = len(bot.guilds)
    total_members = sum(len(guild.members) for guild in bot.guilds)
    embed = discord.Embed(title='ℹ️ INFORMAÇÃO DO DONO', description='Dados globais do Dextroier.', color=0xF59E0B)
    embed.add_field(name='🖥️ Servidores', value=str(guild_count), inline=True)
    embed.add_field(name='👥 Usuários', value=str(total_members), inline=True)
    embed.add_field(name='📡 Latência', value=f'{latency} ms', inline=True)
    embed.add_field(name='🟢 Status', value='Online', inline=True)
    embed.add_field(name='🧩 Versão', value='Dextroier v1.0', inline=True)
    return embed


class GlobalMessageModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title='🌎 Mensagem Global')
        self.message = discord.ui.TextInput(label='Mensagem', placeholder='Olá! Temos novidades no Dex Bot.', style=discord.TextStyle.long, required=True, min_length=1, max_length=2000)
        self.add_item(self.message)

    async def on_submit(self, interaction: discord.Interaction):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        text = self.message.value.strip()
        if not text:
            await interaction.response.send_message('❌ A mensagem não pode estar vazia.', ephemeral=True)
            return
        PENDING_GLOBAL_MESSAGES[interaction.user.id] = text
        embed = discord.Embed(title='🌎 MENSAGEM GLOBAL', description='Você está prestes a enviar esta mensagem para todos os servidores:', color=0xF59E0B)
        embed.add_field(name='Mensagem', value=f'"{text}"', inline=False)
        await interaction.response.send_message(embed=embed, view=OwnerGlobalConfirmView(), ephemeral=True)


class OwnerGlobalConfirmView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label='✅ Enviar para Todos', style=discord.ButtonStyle.success, custom_id='owner_global_confirm')
    async def confirmar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        text = PENDING_GLOBAL_MESSAGES.pop(interaction.user.id, '')
        if not text:
            await interaction.response.send_message('❌ Nenhuma mensagem pendente foi encontrada.', ephemeral=True)
            return
        sent = 0
        failed = 0
        for guild in bot.guilds:
            dest = await get_primary_global_channel(guild)
            if dest is None:
                failed += 1
                continue
            try:
                await dest.send(text)
                sent += 1
            except Exception:
                failed += 1
        embed = discord.Embed(title='🌎 MENSAGEM ENVIADA', description='Resumo da entrega da mensagem global.', color=0xF59E0B)
        embed.add_field(name='✅ Enviada para', value=f'{sent} servidores', inline=True)
        embed.add_field(name='❌ Falharam', value=f'{failed} servidores', inline=True)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label='❌ Cancelar', style=discord.ButtonStyle.danger, custom_id='owner_global_cancel')
    async def cancelar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != OWNER_USER_ID:
            await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
            return
        PENDING_GLOBAL_MESSAGES.pop(interaction.user.id, None)
        await interaction.response.send_message('❌ Envio cancelado.', ephemeral=True)


async def open_admin_menu(interaction: discord.Interaction | discord.ext.commands.Context):
    if interaction is None:
        return
    if isinstance(interaction, discord.ext.commands.Context):
        if interaction.author is None or interaction.guild is None:
            return
        member = interaction.author
        if not member.guild_permissions.administrator:
            await interaction.reply('❌ Você não possui permissão para acessar o Menu Admin.')
            return
        embed = build_admin_menu_embed()
        await interaction.reply(embed=embed, view=AdminMenuView())
        return
    if interaction.guild is None:
        await interaction.response.send_message('❌ Este comando só pode ser usado em um servidor.', ephemeral=True)
        return
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message('❌ Você não possui permissão para acessar o Menu Admin.', ephemeral=True)
        return
    await interaction.response.send_message(embed=build_admin_menu_embed(), view=AdminMenuView(), ephemeral=True)


async def open_owner_menu(interaction: discord.Interaction | discord.ext.commands.Context):
    if interaction is None:
        return
    if isinstance(interaction, discord.ext.commands.Context):
        if interaction.author is None:
            return
        if interaction.author.id != OWNER_USER_ID:
            await interaction.reply('❌ Você não é o dono do bot.')
            return
        await interaction.reply(embed=build_owner_menu_embed(), view=OwnerMenuView())
        return
    if interaction.user.id != OWNER_USER_ID:
        await interaction.response.send_message('❌ Você não é o dono do bot.', ephemeral=True)
        return
    await interaction.response.send_message(embed=build_owner_menu_embed(), view=OwnerMenuView(), ephemeral=True)


@bot.event
async def on_message(message):
    if message.author.bot:
        await bot.process_commands(message)
        return
    if message.author.id != OWNER_USER_ID:
        await bot.process_commands(message)
        return
    if message.attachments:
        if len(message.attachments) != 1:
            await message.reply('❌ Envie apenas o arquivo `AIpromt.txt`.', delete_after=15)
            return
        attachment = message.attachments[0]
        if attachment.filename.lower() != 'aiprompt.txt':
            await message.reply('❌ Arquivo inválido. Envie apenas `AIpromt.txt`.', delete_after=15)
            return
        if attachment.size > 200000:
            await message.reply('❌ Arquivo muito grande. O máximo permitido é 200 KB.', delete_after=15)
            return
        try:
            data = await attachment.read()
            text = data.decode('utf-8')
        except Exception:
            await message.reply('❌ Não foi possível ler o arquivo enviado.', delete_after=15)
            return
        if not text.strip():
            await message.reply('❌ O arquivo está vazio.', delete_after=15)
            return
        try:
            with open(AI_PROMPT_FILE, 'w', encoding='utf-8') as file_handle:
                file_handle.write(text)
        except Exception:
            await message.reply('❌ Falha ao substituir o `AIpromt.txt`.', delete_after=15)
            return
        await message.reply('## ✅ AIpromt.txt atualizado\nO novo arquivo foi carregado com sucesso.\nA Dextroier AI utilizará as novas instruções nas próximas conversas.', delete_after=20)
        return
    await bot.process_commands(message)


@bot.event
async def on_ready():
    ensure_ai_prompt_file()
    await bot.tree.sync()
    print(f'Bot conectado como: {bot.user} (ID: {bot.user.id})')


@bot.command(name='menu')
async def menu_prefix(ctx):
    embed = discord.Embed(
        title='🎮 Dextroier',
        description='Escolha uma opção abaixo.',
        color=0x8B5CF6,
    )
    await ctx.send(embed=embed, view=MenuView())


@bot.tree.command(name='menu', description='Abre o menu social do bot.')
async def menu_slash(interaction: discord.Interaction):
    embed = discord.Embed(
        title='🎮 Dextroier',
        description='Escolha uma opção abaixo.',
        color=0x8B5CF6,
    )
    await interaction.response.send_message(embed=embed, view=MenuView(), ephemeral=True)


@bot.command(name='menuadmin')
async def menuadmin_prefix(ctx):
    await open_admin_menu(ctx)


@bot.tree.command(name='menuadmin', description='Abre o painel administrativo do servidor.')
async def menuadmin_slash(interaction: discord.Interaction):
    await open_admin_menu(interaction)


@bot.command(name='menudono')
async def menudono_prefix(ctx):
    await open_owner_menu(ctx)


@bot.tree.command(name='menudono', description='Abre o painel exclusivo do dono do bot.')
async def menudono_slash(interaction: discord.Interaction):
    await open_owner_menu(interaction)


@bot.command()
async def ping(ctx):
    await ctx.send('Pong!')


@bot.command()
async def hello(ctx, nome: str = 'mundo'):
    await ctx.send(f'Olá, {nome}!')


if __name__ == '__main__':
    token = None
    token_path = os.path.join(os.path.dirname(__file__), 'token.txt')
    if os.path.isfile(token_path):
        with open(token_path, 'r', encoding='utf-8') as f:
            token = f.read().strip()
    if not token:
        token = os.getenv('DISCORD_TOKEN')
    if not token:
        raise ValueError('Token do Discord não encontrado. coloque o token em token.txt ao lado de bot.py ou defina a variável de ambiente DISCORD_TOKEN.')
    bot.run(token)
